package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Luxury Deep Slate & Obsidian Base Palette (bg-[#050505])
val ObsidianBackground = Color(0xFF050505)         // Absolute premium deep dark canvas
val ObsidianSurface = Color(0xFF121212)            // Premium background surface
val TranslucentGlass = Color(0x1AFFFFFF)           // Translucent white with 10% opacity for glassmorphism
val ObsidianContainer = Color(0xFF1E1E1E)          // Subtle thin borders & highlights

// Luxury Metallic Accent Tones
val GoldLuxury = Color(0xFFF59E0B)                 // Luxury gold/amber accent (amber-500)
val BronzeGold = Color(0xFFFBBF24)                 // Light luxury gold highlight (yellow-200)
val SilverText = Color(0xFFF8FAFC)                 // High contrast Slate 50/100 body text
val SlateMuted = Color(0xFF94A3B8)                 // Low contrast Slate 400 secondary labels

// Action Indicator Accents
val NeonActiveCyan = Color(0xFF00E1D4)             // System active pulse
val BullishGreen = Color(0xFF10B981)               // Positive yield emerald-500
val BearishRed = Color(0xFFEF4444)                 // Negative risk trigger red
val WarnAmber = Color(0xFFF59E0B)                  // System alarm warning amber
