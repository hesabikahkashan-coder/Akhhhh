package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val LuxuryDarkColorScheme = darkColorScheme(
    primary = GoldLuxury,
    secondary = NeonActiveCyan,
    tertiary = BronzeGold,
    background = ObsidianBackground,
    surface = ObsidianSurface,
    onBackground = SilverText,
    onSurface = SilverText,
    surfaceVariant = ObsidianContainer,
    onSurfaceVariant = SlateMuted
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    // Force Persian RTL layout direction support globally across all screens!
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = LuxuryDarkColorScheme,
            typography = Typography,
            content = content
        )
    }
}
