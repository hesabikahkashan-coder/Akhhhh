package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trades")
data class Trade(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val symbol: String,
    val side: String, // LONG, SHORT
    val leverage: Int,
    val margin: Double,
    val entryPrice: Double,
    val exitPrice: Double,
    val pnlUsdt: Double,
    val pnlPercent: Double,
    val riskPercent: Double,
    val openTime: Long,
    val closeTime: Long,
    val reasonForEntry: String,
    val reasonForExit: String,
    val aiScore: Int
)
