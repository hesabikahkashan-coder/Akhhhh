package com.example.data

import com.example.BuildConfig
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GroqMessage(
    @Json(name = "role") val role: String,
    @Json(name = "content") val content: String
)

@JsonClass(generateAdapter = true)
data class GroqChatRequest(
    @Json(name = "model") val model: String,
    @Json(name = "messages") val messages: List<GroqMessage>,
    @Json(name = "temperature") val temperature: Double = 0.7
)

@JsonClass(generateAdapter = true)
data class GroqMessageResponse(
    @Json(name = "role") val role: String?,
    @Json(name = "content") val content: String?
)

@JsonClass(generateAdapter = true)
data class GroqChoice(
    @Json(name = "message") val message: GroqMessageResponse?
)

@JsonClass(generateAdapter = true)
data class GroqChatResponse(
    @Json(name = "choices") val choices: List<GroqChoice>?
)

interface GroqApi {
    @POST("v1/chat/completions")
    suspend fun getChatCompletion(
        @Header("Authorization") authHeader: String,
        @Body request: GroqChatRequest
    ): GroqChatResponse
}

object GroqClient {
    private const val BASE_URL = "https://api.groq.com/openai/"
    
    val MODELS = listOf(
        "llama-3.1-8b-instant",
        "meta-llama/llama-4-scout-17b-16e-instruct",
        "llama-3.3-70b-versatile",
        "whisper-large-v3-turbo"
    )

    private val okHttpClient = OkHttpClient.Builder()
        .dns(SafeDns)
        .addInterceptor(SafeInterceptor)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create())
        .build()

    val api: GroqApi = retrofit.create(GroqApi::class.java)

    suspend fun askGroq(prompt: String, model: String = "llama-3.1-8b-instant"): String {
        if (!SafeNetwork.isNetworkPermitted) {
            return "MOCK_MODE"
        }
        val key = BuildConfig.GROQ_API_KEY
        if (key.isBlank() || key == "gsk_PLACEHOLDER_KEY" || key.contains("PLACEHOLDER") || key.contains("MY_")) {
            return "MOCK_MODE"
        }
        return try {
            val authHeader = "Bearer $key"
            val request = GroqChatRequest(
                model = model,
                messages = listOf(
                    GroqMessage(role = "user", content = prompt)
                )
            )
            val response = api.getChatCompletion(authHeader, request)
            response.choices?.firstOrNull()?.message?.content ?: ""
        } catch (e: Exception) {
            e.printStackTrace()
            "ERROR: ${e.localizedMessage}"
        }
    }
}
