package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "alerts")
data class Alert(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val message: String,
    val type: String, // ENTRY, EXIT, TP, SL, PUMP_DUMP, NEWS
    val timestamp: Long = System.currentTimeMillis()
)
