package com.example.data

import com.example.BuildConfig
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

@JsonClass(generateAdapter = true)
data class BinanceTicker24h(
    @Json(name = "symbol") val symbol: String,
    @Json(name = "lastPrice") val lastPrice: String,
    @Json(name = "priceChangePercent") val priceChangePercent: String,
    @Json(name = "volume") val volume: String? = null
)

@JsonClass(generateAdapter = true)
data class BinanceAssetBalance(
    @Json(name = "asset") val asset: String,
    @Json(name = "free") val free: String,
    @Json(name = "locked") val locked: String
)

@JsonClass(generateAdapter = true)
data class BinanceAccountInfo(
    @Json(name = "balances") val balances: List<BinanceAssetBalance>? = null
)

interface BinanceApi {
    @GET("api/v3/ticker/24hr")
    suspend fun get24hTickers(): List<BinanceTicker24h>

    @GET("api/v3/account")
    suspend fun getAccountInfo(
        @Header("X-MBX-APIKEY") apiKey: String,
        @Query("timestamp") timestamp: Long,
        @Query("signature") signature: String
    ): BinanceAccountInfo
}

object BinanceClient {
    private const val BASE_URL = "https://api.binance.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .dns(SafeDns)
        .addInterceptor(SafeInterceptor)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create())
        .build()

    val api: BinanceApi = retrofit.create(BinanceApi::class.java)

    private fun generateHmacSignature(data: String, secret: String): String {
        return try {
            val secretKeySpec = SecretKeySpec(secret.toByteArray(), "HmacSHA256")
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(secretKeySpec)
            val rawHmac = mac.doFinal(data.toByteArray())
            rawHmac.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            e.printStackTrace()
            ""
        }
    }

    /**
     * Fetches the real live account balance in USDT from Binance using API integrations.
     */
    suspend fun fetchRealBalance(): Double? {
        if (!SafeNetwork.isNetworkPermitted) {
            return null
        }
        val apiKey = BuildConfig.BINANCE_API_KEY
        val secretKey = BuildConfig.BINANCE_SECRET_KEY
        
        if (apiKey.isBlank() || apiKey.contains("PLACEHOLDER") || secretKey.isBlank() || secretKey.contains("PLACEHOLDER")) {
            return null
        }
        
        return try {
            val timestamp = System.currentTimeMillis()
            val queryString = "timestamp=$timestamp"
            val signature = generateHmacSignature(queryString, secretKey)
            
            val info = api.getAccountInfo(apiKey, timestamp, signature)
            val usdtBalance = info.balances?.find { it.asset == "USDT" }
            val freeAmount = usdtBalance?.free?.toDoubleOrNull() ?: 0.0
            val lockedAmount = usdtBalance?.locked?.toDoubleOrNull() ?: 0.0
            freeAmount + lockedAmount
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Fetches public list of live prices from Binance endpoint
     */
    suspend fun fetchLiveBinanceTickers(): List<BinanceTicker24h>? {
        if (!SafeNetwork.isNetworkPermitted) {
            return null
        }
        return try {
            api.get24hTickers()
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
