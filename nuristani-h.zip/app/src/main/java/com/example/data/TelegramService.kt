package com.example.data

import com.example.BuildConfig
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Path
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class TelegramMessageRequest(
    @Json(name = "chat_id") val chatId: String,
    @Json(name = "text") val text: String,
    @Json(name = "parse_mode") val parseMode: String = "HTML"
)

@JsonClass(generateAdapter = true)
data class TelegramResponse(
    @Json(name = "ok") val ok: Boolean
)

interface TelegramApi {
    @POST("bot{token}/sendMessage")
    suspend fun sendMessage(
        @Path("token") token: String,
        @Body request: TelegramMessageRequest
    ): TelegramResponse
}

object TelegramClient {
    private const val BASE_URL = "https://api.telegram.org/"

    private val okHttpClient = OkHttpClient.Builder()
        .dns(SafeDns)
        .addInterceptor(SafeInterceptor)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create())
        .build()

    val api: TelegramApi = retrofit.create(TelegramApi::class.java)

    suspend fun sendPulseMessage(text: String): Boolean {
        if (!SafeNetwork.isNetworkPermitted) {
            return false
        }
        val chatId = BuildConfig.TELEGRAM_CHAT_ID
        val token = BuildConfig.TELEGRAM_TOKEN
        if (chatId.isBlank() || chatId.contains("PLACEHOLDER") || token.isBlank() || token.contains("PLACEHOLDER")) {
            return false
        }
        return try {
            val request = TelegramMessageRequest(chatId = chatId, text = text)
            val response = api.sendMessage(token, request)
            response.ok
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
