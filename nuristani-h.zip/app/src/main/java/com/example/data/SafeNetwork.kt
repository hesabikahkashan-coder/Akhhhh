package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Dns
import okhttp3.Interceptor
import okhttp3.Response
import java.io.IOException
import java.net.InetAddress
import java.net.UnknownHostException

object SafeNetwork {
    @Volatile
    var isNetworkPermitted: Boolean = true

    suspend fun checkNetworkVerification(): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                // Perform a simple test to check if the Android system throws SecurityException/EPERM
                val testAddr = InetAddress.getByName("8.8.8.8")
                isNetworkPermitted = true
                true
            } catch (e: SecurityException) {
                isNetworkPermitted = false
                false
            } catch (e: Throwable) {
                // Any other exception, e.g. UnknownHostException or SocketException, 
                // means network sockets are allowed but the device is currently offline.
                isNetworkPermitted = true
                true
            }
        }
    }
}

object SafeDns : Dns {
    override fun lookup(hostname: String): List<InetAddress> {
        if (!SafeNetwork.isNetworkPermitted) {
            throw UnknownHostException("Network connections are disabled due to SecurityException constraints on this sandbox")
        }
        return try {
            Dns.SYSTEM.lookup(hostname)
        } catch (e: SecurityException) {
            SafeNetwork.isNetworkPermitted = false
            throw UnknownHostException("Security permission denied for DNS lookup of $hostname").apply {
                initCause(e)
            }
        } catch (e: Exception) {
            throw UnknownHostException("Error looking up DNS for $hostname: ${e.message}").apply {
                initCause(e)
            }
        }
    }
}

object SafeInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        if (!SafeNetwork.isNetworkPermitted) {
            throw IOException("Network connections are globally paused due to system permission constraints")
        }
        try {
            return chain.proceed(chain.request())
        } catch (e: SecurityException) {
            SafeNetwork.isNetworkPermitted = false
            throw IOException("SecurityException: Internet connection block or permission issue caught on pipeline connection", e)
        } catch (e: IllegalArgumentException) {
            throw IOException("IllegalArgumentException inside request execution: ${e.message}", e)
        } catch (e: NullPointerException) {
            throw IOException("NullPointerException inside request execution: ${e.message}", e)
        } catch (e: Exception) {
            if (e is IOException) {
                throw e
            } else {
                throw IOException("Network request dispatcher custom exception: ${e.message}", e)
            }
        }
    }
}
