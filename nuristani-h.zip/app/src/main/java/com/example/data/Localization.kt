package com.example.data

/**
 * Premium in-line translation extension for Jetpack Compose UI.
 * Usage: "متن فارسی".t("English Version", isEnglish)
 */
fun String.t(en: String, isEnglish: Boolean): String {
    return if (isEnglish) en else this
}
