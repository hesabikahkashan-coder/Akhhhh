package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.screens.*
import com.example.data.t
import com.example.ui.theme.GoldLuxury
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.SlateMuted
import com.example.viewmodel.TradingViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Edge to edge immersive layout support as mandated
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val viewModel: TradingViewModel = viewModel()
                var currentScreen by remember { mutableStateOf("DASHBOARD") } // DASHBOARD, CHART, SCANNER, AI_HUB, HISTORY
                val isEnglish by viewModel.isEnglish.collectAsState()
                val layoutDirection = if (isEnglish) LayoutDirection.Ltr else LayoutDirection.Rtl

                CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        bottomBar = {
                            LuxuryBottomAppBar(
                                selectedTab = currentScreen,
                                isEnglish = isEnglish,
                                onTabSelected = { currentScreen = it }
                            )
                        },
                        containerColor = ObsidianBackground
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                                .background(color = ObsidianBackground)
                        ) {
                            when (currentScreen) {
                                "DASHBOARD" -> DashboardScreen(viewModel = viewModel)
                                "CHART" -> ChartScreen(viewModel = viewModel)
                                "SCANNER" -> OpportunityScreen(
                                    viewModel = viewModel,
                                    onNavigateToChart = { currentScreen = "CHART" }
                                )
                                "AI_HUB" -> IntelligenceScreen(viewModel = viewModel)
                                "HISTORY" -> HistoryScreen(viewModel = viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LuxuryBottomAppBar(
    selectedTab: String,
    isEnglish: Boolean,
    onTabSelected: (String) -> Unit
) {
    // Elegant bottom bar layout respecting navigation safe area
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars) // safe navigation space
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(20.dp))
            .border(0.5.dp, Color(0x15FFFFFF), RoundedCornerShape(20.dp)),
        color = Color(0xEE050505), // Ultra luxury translucent obsidian background
        tonalElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomNavItem(
                label = "داشبورد".t("Dashboard", isEnglish),
                icon = Icons.Default.Home,
                isSelected = selectedTab == "DASHBOARD",
                onClick = { onTabSelected("DASHBOARD") },
                tagId = "nav_dashboard"
            )

            BottomNavItem(
                label = "چارت".t("Chart", isEnglish),
                icon = Icons.Default.ShowChart,
                isSelected = selectedTab == "CHART",
                onClick = { onTabSelected("CHART") },
                tagId = "nav_chart"
            )

            BottomNavItem(
                label = "اسکنر".t("Scanner", isEnglish),
                icon = Icons.Default.Search,
                isSelected = selectedTab == "SCANNER",
                onClick = { onTabSelected("SCANNER") },
                tagId = "nav_scanner"
            )

            BottomNavItem(
                label = "هوشمند".t("Intelligence", isEnglish),
                icon = Icons.Default.Info,
                isSelected = selectedTab == "AI_HUB",
                onClick = { onTabSelected("AI_HUB") },
                tagId = "nav_ai_hub"
            )

            BottomNavItem(
                label = "تاریخچه".t("History", isEnglish),
                icon = Icons.Default.List,
                isSelected = selectedTab == "HISTORY",
                onClick = { onTabSelected("HISTORY") },
                tagId = "nav_history"
            )
        }
    }
}

@Composable
fun BottomNavItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    tagId: String
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag(tagId),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isSelected) GoldLuxury else SlateMuted,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) GoldLuxury else SlateMuted,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
