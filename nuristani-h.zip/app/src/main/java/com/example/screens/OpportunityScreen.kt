package com.example.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.ScannedCoin
import com.example.viewmodel.TradingViewModel
import com.example.data.t

@Composable
fun OpportunityScreen(viewModel: TradingViewModel, onNavigateToChart: () -> Unit) {
    val scannedCoins by viewModel.scannedCoins.collectAsState()
    val isEnglish by viewModel.isEnglish.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, HIGH_VOL, LEVERAGE, SHORT, LONG

    val filteredCoins = scannedCoins.filter { coin ->
        // Search query
        val matchesSearch = coin.symbol.contains(searchQuery, ignoreCase = true)
        
        // Chip Filters
        val matchesFilter = when (selectedFilter) {
            "ALL" -> true
            "HIGH_VOL" -> coin.volatility > 9.5
            "LEVERAGE" -> coin.leverageAvailable >= 30
            "LONG" -> coin.action == "LONG"
            "SHORT" -> coin.action == "SHORT"
            else -> true
        }

        matchesSearch && matchesFilter
    }.sortedByDescending { it.score }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Upper Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "فرصت‌یاب هوشمند اسکنر (۱۵۰ ارز)".t("AI Smart Scanner Opportunity Finder (150 Assets)", isEnglish),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = GoldLuxury
                    )
                )
                Text(
                    text = "فقط ارزهای با کیفیت فیوچرز با نقدینگی و نوسان بالا".t("Only high-liquidity futures contracts with high volatility profiles", isEnglish),
                    color = SlateMuted,
                    fontSize = 11.sp
                )
            }
            Icon(
                imageVector = Icons.Default.ElectricBolt,
                contentDescription = "Fast AI Scan",
                tint = NeonActiveCyan,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Luxury search input box
        TextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("جستجوی نام ارز (مثال: BTC)".t("Search asset (e.g., BTC)", isEnglish), color = SlateMuted, fontSize = 12.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = SlateMuted) },
            colors = TextFieldDefaults.colors(
                focusedContainerColor = ObsidianSurface,
                unfocusedContainerColor = ObsidianSurface,
                disabledContainerColor = ObsidianSurface,
                focusedIndicatorColor = GoldLuxury,
                unfocusedIndicatorColor = ObsidianContainer,
                focusedTextColor = SilverText,
                unfocusedTextColor = SilverText
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(0.5.dp, ObsidianContainer, RoundedCornerShape(12.dp))
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Horizontal scrolling filters row
        val filters = listOf(
            "ALL" to "همه ارزها".t("All Assets", isEnglish),
            "HIGH_VOL" to "🔥 نوسان قوی".t("🔥 High Volatility", isEnglish),
            "LEVERAGE" to "💎 اهرم بالای ۳۰".t("💎 Leverage > 30x", isEnglish),
            "LONG" to "🟢 سیگنال LONG".t("🟢 BUY LONG Signals", isEnglish),
            "SHORT" to "🔴 سیگنال SHORT".t("🔴 SELL SHORT Signals", isEnglish)
        )
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(filters) { (key, label) ->
                val isSelected = key == selectedFilter
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) GoldLuxury.copy(alpha = 0.15f) else ObsidianSurface)
                        .border(
                            width = 1.dp,
                            color = if (isSelected) GoldLuxury else ObsidianContainer,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .clickable { selectedFilter = key }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) GoldLuxury else SlateMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Total scans count
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "رتبه‌بندی بر اساس نمره هوش مصنوعی AI Score".t("Opportunity ranking based on Google Gemini AI score criteria", isEnglish), color = SlateMuted, fontSize = 11.sp)
            Text(
                text = "$0 فرصت صادر شد".replace("$0", filteredCoins.size.toString()).t("${filteredCoins.size} opportunities identified", isEnglish),
                color = NeonActiveCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Core scrolling opportunity cards
        if (filteredCoins.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "ارزی با این مشخصات یافت نشد.".t("No assets found matching the chosen parameters.", isEnglish), color = SlateMuted, fontSize = 13.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredCoins) { coin ->
                    OpportunityRowItem(
                        coin = coin,
                        isEnglish = isEnglish,
                        onClick = {
                            viewModel.selectSymbol(coin.symbol)
                            onNavigateToChart()
                        }
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}

@Composable
fun OpportunityRowItem(coin: ScannedCoin, isEnglish: Boolean, onClick: () -> Unit) {
    val isLONG = coin.action == "LONG"
    val isSHORT = coin.action == "SHORT"
    val isBullish = coin.change24h >= 0

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x0CFFFFFF))
            .border(0.5.dp, Color(0x13FFFFFF), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag("opportunity_row_${coin.symbol.replace("/", "_")}")
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Main asset info
            Column(modifier = Modifier.weight(1.3f)) {
                Text(
                    text = coin.symbol,
                    color = SilverText,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = String.format("%,.4f US", coin.price),
                        color = SlateMuted,
                        fontSize = 10.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = String.format("%+.2f%%", coin.change24h),
                        color = if (isBullish) BullishGreen else BearishRed,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // AI Score metric progress
            Column(
                modifier = Modifier.weight(1.5f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth(0.85f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "پتانسیل موفقیت".t("Success Prob.", isEnglish), color = SlateMuted, fontSize = 9.sp)
                    Text(
                        text = "${coin.probability}%",
                        color = GoldLuxury,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = coin.probability / 100f,
                    trackColor = Color(0x12FFFFFF),
                    color = if (isLONG) BullishGreen else if (isSHORT) BearishRed else NeonActiveCyan,
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "نمره نهایی: \$0/۱۰۰".replace("\$0", coin.score.toString()).t("Final Score: ${coin.score}/100", isEnglish),
                    color = SlateMuted,
                    fontSize = 8.sp
                )
            }

            // Trade Signal recommendation button trigger
            Column(
                modifier = Modifier.weight(1.2f),
                horizontalAlignment = Alignment.End
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            when {
                                isLONG -> BullishGreen.copy(alpha = 0.15f)
                                isSHORT -> BearishRed.copy(alpha = 0.15f)
                                else -> Color(0x15FFFFFF)
                            }
                        )
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = when {
                            isLONG -> "معامله LONG".t("BUY LONG", isEnglish)
                            isSHORT -> "معامله SHORT".t("SELL SHORT", isEnglish)
                            else -> "وضعیت خنثی".t("Neutral Bias", isEnglish)
                        },
                        color = when {
                            isLONG -> BullishGreen
                            isSHORT -> BearishRed
                            else -> SlateMuted
                        },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
