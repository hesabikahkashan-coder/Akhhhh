package com.example.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Alert
import com.example.data.Trade
import com.example.ui.theme.*
import com.example.viewmodel.TradingViewModel
import com.example.data.t
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(viewModel: TradingViewModel) {
    val trades by viewModel.tradeHistory.collectAsState()
    val alerts by viewModel.alertsList.collectAsState()
    val balance by viewModel.accountBalance.collectAsState()
    val isEnglish by viewModel.isEnglish.collectAsState()

    var activeTab by remember { mutableStateOf("LEDGER") } // LEDGER, ALERTS, ANALYTICS

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(16.dp))
            // History main title
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "تاریخچه، هشدارها & عملکرد".t("History, Alerts & Performance", isEnglish),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = GoldLuxury
                        )
                    )
                    Text(
                        text = "ثبت دیتابیس واقعی معاملات تهاجمی ربات".t("Secure real-time database ledger of trade actions", isEnglish),
                        color = SlateMuted,
                        fontSize = 11.sp
                    )
                }

                // Reset Ledger button
                IconButton(
                    onClick = { viewModel.clearLedger() },
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(BearishRed.copy(alpha = 0.15f))
                        .border(1.dp, BearishRed.copy(alpha = 0.35f), CircleShape)
                        .testTag("reset_ledger_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "Reset",
                        tint = BearishRed,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Sub tab options row
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(ObsidianSurface)
                    .padding(4.dp)
            ) {
                listOf(
                    "LEDGER" to "دفتر کل معاملات".t("Transaction Ledger", isEnglish),
                    "ALERTS" to "نوتیفیکیشن‌ها".t("System Alerts", isEnglish),
                    "ANALYTICS" to "تحلیل کارایی".t("Performance Analytics", isEnglish)
                ).forEach { (key, title) ->
                    val isSelected = key == activeTab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) GoldLuxury.copy(alpha = 0.15f) else Color.Transparent)
                            .clickable { activeTab = key }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = title,
                            color = if (isSelected) GoldLuxury else SlateMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Selected list content logic
        when (activeTab) {
            "LEDGER" -> {
                if (trades.isEmpty()) {
                    item {
                        EmptyHistoryPlaceholder(
                            msg = "هیچ معامله‌ای هنوز در سیستم ثبت نشده است.".t("No transactions have been recorded in the database yet.", isEnglish),
                            isEnglish = isEnglish
                        )
                    }
                } else {
                    items(trades) { trade ->
                        TradeLedgerRow(trade, isEnglish)
                    }
                }
            }

            "ALERTS" -> {
                if (alerts.isEmpty()) {
                    item {
                        EmptyHistoryPlaceholder(
                            msg = "هیچ هشدار سیستمی صادر نشده است.".t("No system alerts have been generated yet.", isEnglish),
                            isEnglish = isEnglish
                        )
                    }
                } else {
                    items(alerts) { alert ->
                        AlertCenterRow(alert)
                    }
                }
            }

            "ANALYTICS" -> {
                // Analytics statistics summary
                item {
                    AnalyticsSummaryWidget(trades, balance, isEnglish)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun EmptyHistoryPlaceholder(msg: String, isEnglish: Boolean) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0x0CFFFFFF))
            .border(0.5.dp, Color(0x13FFFFFF), RoundedCornerShape(20.dp))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.QueryStats,
                contentDescription = "Empty",
                tint = SlateMuted,
                modifier = Modifier.size(36.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = msg,
                color = SlateMuted,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
            Text(
                text = "با روشن کردن ربات و آغاز معامله‌گری خودکار، این پنل پر خواهد شد.".t("This ledger will automatically populate once active automated trades are executed.", isEnglish),
                color = SlateMuted.copy(alpha = 0.6f),
                fontSize = 9.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
fun TradeLedgerRow(trade: Trade, isEnglish: Boolean) {
    val isProfit = trade.pnlUsdt >= 0
    val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    val formattedTime = sdf.format(Date(trade.closeTime))

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x0CFFFFFF))
            .border(0.5.dp, Color(0x13FFFFFF), RoundedCornerShape(16.dp))
            .testTag("ledger_trade_card_${trade.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (trade.side == "LONG") BullishGreen.copy(alpha = 0.15f) else BearishRed.copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (trade.side == "LONG") "خرید LONG".t("BUY LONG", isEnglish) else "فروش SHORT".t("SELL SHORT", isEnglish),
                            color = if (trade.side == "LONG") BullishGreen else BearishRed,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = trade.symbol,
                        color = SilverText,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Text(
                    text = formattedTime,
                    color = SlateMuted,
                    fontSize = 10.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = Color(0x13FFFFFF), thickness = 1.dp)
            Spacer(modifier = Modifier.height(10.dp))

            // Price statistics
            Row(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "قیمت ورود".t("Entry Price", isEnglish), color = SlateMuted, fontSize = 8.sp)
                    Text(text = String.format("%,.4f", trade.entryPrice), color = SilverText, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "قیمت خروج".t("Exit Price", isEnglish), color = SlateMuted, fontSize = 8.sp)
                    Text(text = String.format("%,.4f", trade.exitPrice), color = SilverText, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }
                Column(
                    modifier = Modifier.weight(1.2f),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(text = "سود و زیان خالص PnL".t("Net PnL Profit", isEnglish), color = SlateMuted, fontSize = 8.sp)
                    Text(
                        text = String.format("%+.2f USDT (%+.1f%%)", trade.pnlUsdt, trade.pnlPercent),
                        color = if (isProfit) BullishGreen else BearishRed,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = Color(0x10FFFFFF), thickness = 1.dp)
            Spacer(modifier = Modifier.height(6.dp))

            // AI reasons for open/close
            Text(
                text = "دلیل ورود: ".t("Reason for Entry: ", isEnglish) + trade.reasonForEntry,
                color = SlateMuted,
                fontSize = 9.sp
            )
            Text(
                text = "دلیل خروج: ".t("Reason for Exit: ", isEnglish) + trade.reasonForExit,
                color = SlateMuted,
                fontSize = 9.sp
            )
        }
    }
}

@Composable
fun AlertCenterRow(alert: Alert) {
    val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    val formattedTime = sdf.format(Date(alert.timestamp))

    val color = when (alert.type) {
        "ENTRY" -> GoldLuxury
        "EXIT", "TP" -> BullishGreen
        "SL" -> BearishRed
        "PUMP_DUMP" -> WarnAmber
        else -> NeonActiveCyan
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x0CFFFFFF))
            .border(0.5.dp, Color(0x13FFFFFF), RoundedCornerShape(14.dp))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.NotificationsActive,
                    contentDescription = "Alert",
                    tint = color,
                    modifier = Modifier.size(12.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = alert.title,
                        color = color,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Text(
                        text = formattedTime,
                        color = SlateMuted,
                        fontSize = 9.sp
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = alert.message,
                    color = SilverText,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
fun AnalyticsSummaryWidget(trades: List<Trade>, currentBalance: Double, isEnglish: Boolean) {
    // Math calculations
    var totalSalesProfit = 0.0
    var totalSalesLoss = 0.0
    var biggestWin = 0.0
    var biggestLoss = 0.0

    trades.forEach {
        if (it.pnlUsdt > 0) {
            totalSalesProfit += it.pnlUsdt
            if (it.pnlUsdt > biggestWin) biggestWin = it.pnlUsdt
        } else {
            totalSalesLoss += Math.abs(it.pnlUsdt)
            if (Math.abs(it.pnlUsdt) > biggestLoss) biggestLoss = Math.abs(it.pnlUsdt)
        }
    }

    val totalCount = trades.size
    val winRatio = if (totalCount > 0) (trades.count { it.pnlUsdt > 0 }.toDouble() / totalCount * 100).toInt() else 0

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        // Core grid statistics card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0x0CFFFFFF))
                .border(0.5.dp, Color(0x13FFFFFF), RoundedCornerShape(20.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "آمار تحلیل عملکرد کل معاملات".t("Comprehensive Trading Performance Analytics", isEnglish),
                    color = GoldLuxury,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )

                Spacer(modifier = Modifier.height(14.dp))
                Divider(color = Color(0x12FFFFFF), thickness = 1.dp)
                Spacer(modifier = Modifier.height(14.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "کل سود حاصله (Gross)".t("Total Realized Gross returns", isEnglish), color = SlateMuted, fontSize = 9.sp)
                        Text(text = String.format("%.2f USDT", totalSalesProfit), color = BullishGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "کل زیان حاصله".t("Total Accumulated drawdowns", isEnglish), color = SlateMuted, fontSize = 9.sp)
                        Text(text = String.format("%.2f USDT", totalSalesLoss), color = BearishRed, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "بزرگترین معامله سودده".t("Maximum Single Profit transaction", isEnglish), color = SlateMuted, fontSize = 9.sp)
                        Text(text = String.format("%.2f USDT", biggestWin), color = BullishGreen, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "بزرگترین معامله زیان‌ده".t("Maximum Single Drawdown transaction", isEnglish), color = SlateMuted, fontSize = 9.sp)
                        Text(text = String.format("%.2f USDT", biggestLoss), color = BearishRed, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }

        // Equity balance curve simulator chart
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0x0CFFFFFF))
                .border(0.5.dp, Color(0x13FFFFFF), RoundedCornerShape(20.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "منحنی رشد اختصاصی سرمایه همواره (Equity Curve)".t("Secure Account Equity Growth Curve", isEnglish),
                    color = GoldLuxury,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "برآیند رشد بالانس حساب بر اساس دنباله سود/زیان پوزیشن‌ها".t("Account value trajectory monitored sequentially on closed trades output", isEnglish),
                    color = SlateMuted,
                    fontSize = 9.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .background(Color(0x12FFFFFF), shape = RoundedCornerShape(10.dp))
                        .padding(8.dp)
                ) {
                    EquityCurveCanvas(trades = trades, modifier = Modifier.fillMaxSize())
                }
            }
        }
    }
}

@Composable
fun EquityCurveCanvas(trades: List<Trade>, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height

        // Calculate points path starting from 1000.0
        val balancePoints = mutableListOf<Double>()
        var curBalance = 1000.0
        balancePoints.add(curBalance)

        trades.reversed().forEach {
            curBalance += it.pnlUsdt
            balancePoints.add(curBalance)
        }

        if (balancePoints.size < 2) {
            // Draw default line if empty
            drawLine(
                color = MutedGoldBrushAccent().colorColor,
                start = Offset(0f, height * 0.5f),
                end = Offset(width, height * 0.5f),
                strokeWidth = 2f
            )
            return@Canvas
        }

        val maxVal = balancePoints.maxOrNull() ?: 1000.0
        val minVal = balancePoints.minOrNull() ?: 1000.0
        val delta = if (maxVal == minVal) 1.0 else maxVal - minVal

        val spacing = width / (balancePoints.size - 1)
        val path = Path()

        balancePoints.forEachIndexed { index, bal ->
            val cx = spacing * index
            val cy = (height - (bal - minVal) / delta * height * 0.82).toFloat() - (height * 0.08).toFloat()

            if (index == 0) {
                path.moveTo(cx, cy)
            } else {
                path.lineTo(cx, cy)
            }
        }

        drawPath(
            path = path,
            color = GoldLuxury,
            style = Stroke(width = 3.5f)
        )
    }
}

class MutedGoldBrushAccent {
    val colorColor = Color(0xFFD4AF37).copy(alpha = 0.35f)
}
