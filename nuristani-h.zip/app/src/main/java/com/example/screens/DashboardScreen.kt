package com.example.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.data.t
import com.example.viewmodel.ActivePosition
import com.example.viewmodel.TradingViewModel

@Composable
fun DashboardScreen(viewModel: TradingViewModel) {
    val isBotActive by viewModel.isBotActive.collectAsState()
    val isLiveMode by viewModel.isLiveMode.collectAsState()
    val isEnglish by viewModel.isEnglish.collectAsState()
    val accountBalance by viewModel.accountBalance.collectAsState()
    val activePositions by viewModel.activePositions.collectAsState()
    val trades by viewModel.tradeHistory.collectAsState()
    val binanceStatus by viewModel.binanceStatus.collectAsState()
    val groqStatus by viewModel.groqStatus.collectAsState()
    val telegramStatus by viewModel.telegramStatus.collectAsState()
    val scannedCoins by viewModel.scannedCoins.collectAsState()

    var showSettingsModal by remember { mutableStateOf(false) }

    // Calculate statistical metrics
    val totalProfit = trades.sumOf { it.pnlUsdt }
    val winTradesCount = trades.count { it.pnlUsdt > 0 }
    val winRate = if (trades.isNotEmpty()) (winTradesCount.toDouble() / trades.size * 100).toInt() else 0

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(color = ObsidianBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Upper Title Header
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Profile/Logo Sphere with Gold gradient border
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(GoldLuxury, BronzeGold)
                                )
                            )
                            .padding(1.dp) // border thickness
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .background(Color.Black),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "N",
                                color = GoldLuxury,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                        }
                    }

                    // Title and status
                    Column {
                        Text(
                            text = "نورستانی H".t("NURISTANI H", isEnglish),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = SilverText
                            )
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(BullishGreen) // emerald-500 indicator
                            )
                            Text(
                                text = "متصل به Binance".t("Connected to Binance", isEnglish),
                                color = BullishGreen,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Interactive settings and notification buttons
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Language Toggle Button (EN / FA)
                    Box(
                        modifier = Modifier
                            .size(width = 62.dp, height = 40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x0DFFFFFF)) // white/5
                            .border(0.5.dp, Color(0x1BFFFFFF), RoundedCornerShape(12.dp))
                            .clickable { viewModel.toggleLanguage() }
                            .testTag("dashboard_lang_toggle"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isEnglish) "FA 🇮🇷" else "EN 🇬🇧",
                            color = GoldLuxury,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 11.sp
                        )
                    }

                    // Settings Cog button (Golden Accent)
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x0DFFFFFF)) // white/5
                            .border(0.5.dp, Color(0x1BFFFFFF), RoundedCornerShape(12.dp))
                            .clickable { showSettingsModal = true }
                            .testTag("dashboard_settings_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = GoldLuxury,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Interactive notification trigger button
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x0DFFFFFF)) // white/5
                            .border(0.5.dp, Color(0x1AFFFFFF), RoundedCornerShape(12.dp))
                            .clickable { showSettingsModal = true }, // clicking notification center also shows setting modal
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Notifications",
                            tint = SilverText,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        // 0. Live Cryptocurrency Price Tickers (Horizontal Scroll)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "آنالیز زنده قیمت رمز ارزها (Binance Tickers)".t("Live Crypto Pricing (Binance)", isEnglish),
                        color = GoldLuxury,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Right
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(NeonActiveCyan)
                        )
                        Text(
                            text = "بروزرسانی لحظه‌ای".t("Live Feed", isEnglish),
                            color = SlateMuted,
                            fontSize = 9.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(scannedCoins.take(8)) { coin ->
                        val isUp = coin.change24h >= 0
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0x0CFFFFFF))
                                .border(
                                    width = 1.dp,
                                    color = if (isUp) BullishGreen.copy(alpha = 0.25f) else BearishRed.copy(alpha = 0.25f),
                                    shape = RoundedCornerShape(16.dp)
                                )
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                                .widthIn(min = 120.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.Start) {
                                Text(
                                    text = coin.symbol.substringBefore("/"),
                                    color = SilverText,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = String.format(if (coin.price >= 1.0) "%,.2f" else "%,.4f" , coin.price),
                                    color = SilverText,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 13.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(5.dp)
                                            .clip(CircleShape)
                                            .background(if (isUp) BullishGreen else BearishRed)
                                    )
                                    Text(
                                        text = String.format("%+.2f%%", coin.change24h),
                                        color = if (isUp) BullishGreen else BearishRed,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 1. Account balances, PnL details - Luxury card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color(0x1AFFFFFF), Color(0x05FFFFFF))
                        )
                    )
                    .border(
                        width = 1.dp,
                        color = Color(0x1AFFFFFF),
                        shape = RoundedCornerShape(24.dp)
                    )
                    .padding(20.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "موجودی کل حساب".t("Total Account Balance", isEnglish), color = SlateMuted, fontSize = 12.sp)
                        
                        // Mode selector pill (Mini-toggle)
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0x1A000000))
                                .border(0.5.dp, Color(0x15FFFFFF), RoundedCornerShape(12.dp))
                                .clickable { viewModel.toggleLiveMode() }
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(if (isLiveMode) WarnAmber else NeonActiveCyan)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isLiveMode) "LIVE واقعی".t("LIVE trading", isEnglish) else "DEMO دمو".t("DEMO Sandbox", isEnglish),
                                fontSize = 9.sp,
                                color = SilverText,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = String.format("%,.2f USDT", accountBalance),
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = SilverText,
                            letterSpacing = 1.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = Color(0x15FFFFFF), thickness = 1.dp)
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "بازدهی معاملات امروز".t("Today's Net Return", isEnglish), color = SlateMuted, fontSize = 11.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            val todaySimPnl = totalProfit * 0.42
                            Text(
                                text = String.format("%+,.2f USDT", todaySimPnl),
                                color = if (todaySimPnl >= 0) BullishGreen else BearishRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                        Box(
                            modifier = Modifier
                                .width(1.dp)
                                .height(35.dp)
                                .background(Color(0x10FFFFFF))
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "کل سود حاصل شده CPU".t("Total Realized Profit", isEnglish), color = SlateMuted, fontSize = 11.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = String.format("%+,.2f USDT", totalProfit),
                                color = if (totalProfit >= 0) BullishGreen else BearishRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }

        // API Connections status panel - Luxury monitoring
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0x09FFFFFF))
                    .border(width = 1.dp, color = Color(0x10FFFFFF), shape = RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "وضعیت پایانه‌های ارتباطی VIP".t("VIP Terminal Gateway Status", isEnglish),
                            color = GoldLuxury,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(
                            modifier = Modifier.clickable { viewModel.checkAllApiConnections() },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh Connections",
                                tint = GoldLuxury,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "بروزرسانی وضعیت".t("Refresh Connections", isEnglish),
                                color = GoldLuxury,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Divider(color = Color(0x0AFFFFFF), thickness = 1.dp)

                    // Binance Feed Status
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "🔸 " + "اتصال صرافی بایننس (Binance API)".t("Binance Exchange API Connection", isEnglish), color = SilverText, fontSize = 10.sp)
                        Text(text = binanceStatus, color = SilverText, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }

                    // Groq AI Status
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "🔸 " + "هوش مصنوعی محاسباتی (Groq LLM)".t("Groq Computational Intelligence Agent", isEnglish), color = SilverText, fontSize = 10.sp)
                        Text(text = groqStatus, color = SilverText, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }

                    // Telegram Notify Status
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "🔸 " + "کانال هشدار معاملات (Telegram Bot)".t("Telegram Notification Alert Gateway", isEnglish), color = SilverText, fontSize = 10.sp)
                        Text(text = telegramStatus, color = SilverText, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Statistical indicators widgets
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatPill(
                    title = "پوزیشن های باز".t("Open Positions", isEnglish),
                    value = "${activePositions.size}",
                    icon = Icons.Default.TrendingUp,
                    color = NeonActiveCyan,
                    modifier = Modifier.weight(1f)
                )
                StatPill(
                    title = "معاملات بسته".t("Closed Trades", isEnglish),
                    value = "${trades.size}",
                    icon = Icons.Default.CheckCircle,
                    color = GoldLuxury,
                    modifier = Modifier.weight(1f)
                )
                StatPill(
                    title = "نرخ برد (WinRate)".t("Win Rate (WinRate)", isEnglish),
                    value = "$winRate%",
                    icon = Icons.Default.Star,
                    color = BullishGreen,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // B. Bot ON/OFF Big Toggle Button
        item {
            val infiniteTransition = rememberInfiniteTransition(label = "pulse")
            val glowIntensity by infiniteTransition.animateFloat(
                initialValue = 0.3f,
                targetValue = 0.85f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1500, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "glow"
            )

            val borderGlowBrush = if (isBotActive) {
                Brush.linearGradient(
                    colors = listOf(
                        BullishGreen.copy(alpha = glowIntensity),
                        NeonActiveCyan.copy(alpha = glowIntensity * 0.4f)
                    )
                )
            } else {
                Brush.linearGradient(
                    colors = listOf(
                        BearishRed.copy(alpha = 0.4f),
                        ObsidianContainer
                    )
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(ObsidianSurface)
                    .border(width = 1.5.dp, brush = borderGlowBrush, shape = RoundedCornerShape(20.dp))
                    .clickable { viewModel.toggleBot() }
                    .testTag("bot_toggle_btn")
                    .padding(18.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(14.dp)
                            .clip(CircleShape)
                            .background(if (isBotActive) BullishGreen else BearishRed)
                            .shadow(
                                elevation = 8.dp,
                                shape = CircleShape,
                                clip = false,
                                ambientColor = if (isBotActive) BullishGreen else BearishRed,
                                spotColor = if (isBotActive) BullishGreen else BearishRed
                            )
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(horizontalAlignment = Alignment.Start) {
                        Text(
                            text = if (isBotActive) "🟢 ربات معاملاتی تهاجمی فعال است".t("🟢 Aggressive Trading Bot is ACTIVE", isEnglish) else "🔴 ربات معاملاتی هم‌اکنون خاموش است".t("🔴 Aggressive Trading Bot is OFFLINE", isEnglish),
                            color = if (isBotActive) BullishGreen else BearishRed,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = if (isBotActive) "سریع‌ترین اسکن بازار و معاملات اتوماتیک فعال".t("Auto scan and automated trading active", isEnglish) else "برای فعالسازی مجدد اتوترید کلیک کنید".t("Click here to reactivate auto trading", isEnglish),
                            color = SlateMuted,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Section Title: Active Positions
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "موقعیت‌های باز لحظه‌ای هجومی".t("Open Margin/Leverage Positions", isEnglish),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = SilverText
                    )
                )
                Text(
                    text = "${activePositions.size} $0".replace("$0", "موقعیت فعال".t("Active Positions", isEnglish)),
                    color = NeonActiveCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        if (activePositions.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(ObsidianSurface)
                        .padding(vertical = 34.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "No Open Positions",
                            tint = SlateMuted,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "هیچ موقعیت بازی وجود ندارد".t("No Positions are currently active", isEnglish),
                            color = SlateMuted,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "ربات بر اساس سیگنال‌های تهاجمی معامله باز خواهد کرد.".t("The AI bot executes margins dynamically on high-score signals.", isEnglish),
                            color = SlateMuted.copy(alpha = 0.7f),
                            fontSize = 10.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        } else {
            items(activePositions) { pos ->
                ActivePositionCard(pos, onExit = { viewModel.closeActivePosition(pos.id, "خروج مصلحتی دستی با کلیک کاربر") })
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showSettingsModal) {
        DashboardSettingsModal(
            viewModel = viewModel,
            onDismissRequest = { showSettingsModal = false }
        )
    }
}

@Composable
fun DashboardSettingsModal(
    viewModel: TradingViewModel,
    onDismissRequest: () -> Unit
) {
    val telegramAlertsEnabled by viewModel.telegramNotificationsEnabled.collectAsState()
    val isBotActive by viewModel.isBotActive.collectAsState()
    val isLiveMode by viewModel.isLiveMode.collectAsState()
    val telegramStatus by viewModel.telegramStatus.collectAsState()
    val isEnglish by viewModel.isEnglish.collectAsState()

    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismissRequest,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x99000000)) // Translucent dim overlay
                .clickable { onDismissRequest() },
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .widthIn(max = 420.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(ObsidianSurface)
                    .border(1.dp, GoldLuxury.copy(alpha = 0.35f), RoundedCornerShape(24.dp))
                    .clickable(enabled = false) { } // prevent clicks from closing inside
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.Start
                ) {
                    // Header row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(GoldLuxury.copy(alpha = 0.12f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = "Settings Icon",
                                    tint = GoldLuxury,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "تنظیمات پیشرفته پایانه".t("Terminal Advanced Settings", isEnglish),
                                    color = SilverText,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "VIP Notification Hub",
                                    color = GoldLuxury,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp
                                )
                            }
                        }

                        // Close button
                        IconButton(
                            onClick = onDismissRequest,
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(0x0CFFFFFF))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = SlateMuted,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))
                    Divider(color = Color(0x12FFFFFF), thickness = 1.dp)
                    Spacer(modifier = Modifier.height(18.dp))

                    // SECTION 0: Language Settings
                    Text(
                        text = "زبان سیستم (System Language)".t("System Language (زبان سیستم)", isEnglish),
                        color = GoldLuxury,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0x0CFFFFFF))
                            .border(0.5.dp, Color(0x13FFFFFF), RoundedCornerShape(16.dp))
                            .padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "زبان انگلیسی (English Language)".t("Persian Language (زبان فارسی)", isEnglish),
                                    color = SilverText,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "تغییر رابط کاربری به زبان انگلیسی".t("Switch user interface to Persian language", isEnglish),
                                    color = SlateMuted,
                                    fontSize = 10.sp
                                )
                            }
                            
                            Switch(
                                checked = isEnglish,
                                onCheckedChange = { viewModel.toggleLanguage() },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = ObsidianBackground,
                                    checkedTrackColor = GoldLuxury,
                                    uncheckedThumbColor = SlateMuted,
                                    uncheckedTrackColor = Color(0x15FFFFFF),
                                    uncheckedBorderColor = Color(0x25FFFFFF)
                                ),
                                modifier = Modifier.testTag("language_toggle")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // SECTION 1: Telegram Trade Alerts
                    Text(
                        text = "ارتباطات و اعلان‌های لحظه‌ای".t("Communications & Real-time Alerts", isEnglish),
                        color = GoldLuxury,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0x0CFFFFFF))
                            .border(0.5.dp, Color(0x13FFFFFF), RoundedCornerShape(16.dp))
                            .padding(14.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "اعلان تلگرام معاملات".t("Telegram Trade Alerts", isEnglish),
                                        color = SilverText,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "ارسال گزارش سود و ضرر به بات تلگرام اختصاصی".t("Deliver PnL reports to personalized Telegram bot", isEnglish),
                                        color = SlateMuted,
                                        fontSize = 10.sp
                                    )
                                }
                                
                                Switch(
                                    checked = telegramAlertsEnabled,
                                    onCheckedChange = { viewModel.toggleTelegramNotifications() },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = ObsidianBackground,
                                        checkedTrackColor = GoldLuxury,
                                        uncheckedThumbColor = SlateMuted,
                                        uncheckedTrackColor = Color(0x15FFFFFF),
                                        uncheckedBorderColor = Color(0x25FFFFFF)
                                    ),
                                    modifier = Modifier.testTag("telegram_alert_toggle")
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            Divider(color = Color(0x08FFFFFF), thickness = 1.dp)
                            Spacer(modifier = Modifier.height(12.dp))

                            // Status Indicator
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (telegramAlertsEnabled) {
                                                    if (telegramStatus.contains("🟢")) BullishGreen else WarnAmber
                                                } else {
                                                    SlateMuted
                                                }
                                            )
                                    )
                                    Text(
                                        text = "وضعیت بستر اعلان:".t("Alert Channel Gateway:", isEnglish),
                                        color = SlateMuted,
                                        fontSize = 10.sp
                                    )
                                }
                                
                                Text(
                                    text = if (telegramAlertsEnabled) telegramStatus else "غیرفعال دستی ⚪".t("Disabled ⚪", isEnglish),
                                    color = if (telegramAlertsEnabled) SilverText else SlateMuted,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // SECTION 2: Trade Settings (Bot & Simulation)
                    Text(
                        text = "مدیریت ماژول معاملاتی".t("Trading Core Engine Controls", isEnglish),
                        color = GoldLuxury,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0x0CFFFFFF))
                            .border(0.5.dp, Color(0x13FFFFFF), RoundedCornerShape(16.dp))
                            .padding(14.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            // Bot Switch
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "ربات خودکار معامله‌گر".t("Automated Trade Bot", isEnglish),
                                        color = SilverText,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "فعال‌سازی هوش تهاجمی اتوکلاینت".t("Enable aggressive automation engine", isEnglish),
                                        color = SlateMuted,
                                        fontSize = 10.sp
                                    )
                                }
                                Switch(
                                    checked = isBotActive,
                                    onCheckedChange = { viewModel.toggleBot() },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = ObsidianBackground,
                                        checkedTrackColor = GoldLuxury,
                                        uncheckedThumbColor = SlateMuted,
                                        uncheckedTrackColor = Color(0x15FFFFFF),
                                        uncheckedBorderColor = Color(0x25FFFFFF)
                                    ),
                                    modifier = Modifier.testTag("bot_active_toggle")
                                )
                            }

                            Divider(color = Color(0x08FFFFFF), thickness = 1.dp)

                            // Live Mode Switch
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "عملکرد واقعی لایو (Live API)".t("Production LIVE mode (Live API)", isEnglish),
                                        color = SilverText,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "تراکنش روی بازار واقعی بایننس".t("Execute orders directly onto Binance live pricing", isEnglish),
                                        color = SlateMuted,
                                        fontSize = 10.sp
                                    )
                                }
                                Switch(
                                    checked = isLiveMode,
                                    onCheckedChange = { viewModel.toggleLiveMode() },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = ObsidianBackground,
                                        checkedTrackColor = GoldLuxury,
                                        uncheckedThumbColor = SlateMuted,
                                        uncheckedTrackColor = Color(0x15FFFFFF),
                                        uncheckedBorderColor = Color(0x25FFFFFF)
                                    ),
                                    modifier = Modifier.testTag("live_mode_toggle")
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Notice / credentials
                    Text(
                        text = "توکن اتصال تلگرام و چت‌آیدی با امنیت کامل از فایل محرمانه .env سمت سرور خوانده می‌شود.".t("Bot tokens and private chat IDs are loaded with maximum security from the server-side environment variables configuration.", isEnglish),
                        color = SlateMuted,
                        fontSize = 9.sp,
                        lineHeight = 13.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Save / close button
                    Button(
                        onClick = onDismissRequest,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .border(1.dp, GoldLuxury, RoundedCornerShape(12.dp))
                            .testTag("settings_close_btn"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0x15FFFFFF)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "ذخیره و تایید تغییرات".t("Apply & Save Configurations", isEnglish),
                            color = GoldLuxury,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StatPill(
    title: String,
    value: String,
    imageVector: androidx.compose.ui.graphics.vector.ImageVector? = null,
    icon: Any? = null,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x0DFFFFFF)) // bg-white/5
            .border(0.5.dp, Color(0x13FFFFFF), RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val iconToUse = imageVector ?: if (icon is androidx.compose.ui.graphics.vector.ImageVector) icon else null
                if (iconToUse != null) {
                    Icon(
                        imageVector = iconToUse,
                        contentDescription = title,
                        tint = color,
                        modifier = Modifier.size(14.dp)
                    )
                }
                Text(text = title, color = SlateMuted, fontSize = 9.sp)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = SilverText
            )
        }
    }
}

@Composable
fun ActivePositionCard(pos: ActivePosition, onExit: () -> Unit) {
    val isBullish = pos.pnlPercent >= 0

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0x0CFFFFFF))
            .border(
                width = 1.dp,
                color = if (isBullish) BullishGreen.copy(alpha = 0.35f) else BearishRed.copy(alpha = 0.35f),
                shape = RoundedCornerShape(18.dp)
            )
            .padding(14.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (pos.side == "LONG") BullishGreen.copy(alpha = 0.15f) else BearishRed.copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (pos.side == "LONG") "خرید LONG" else "فروش SHORT",
                            color = if (pos.side == "LONG") BullishGreen else BearishRed,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = pos.symbol,
                        color = SilverText,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Text(
                    text = "لوریج ${pos.leverage}x",
                    color = GoldLuxury,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = Color(0x12FFFFFF), thickness = 1.dp)
            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "قیمت ورود", color = SlateMuted, fontSize = 9.sp)
                    Text(text = String.format("%,.4f", pos.entryPrice), color = SilverText, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "قیمت فعلی", color = SlateMuted, fontSize = 9.sp)
                    Text(text = String.format("%,.4f", pos.currentPrice), color = SilverText, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
                Column(
                    modifier = Modifier.weight(1.2f),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(text = "سود و زیان غیرواقعی PnL", color = SlateMuted, fontSize = 9.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = String.format("%+.2f%%", pos.pnlPercent),
                            color = if (isBullish) BullishGreen else BearishRed,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = String.format("(%+.1f USDT)", pos.pnlUsdt),
                            color = if (isBullish) BullishGreen else BearishRed,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action row: Risk info & Exit Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Auto risk notice
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Risk Safe",
                        tint = NeonActiveCyan,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "حد ضرر خودکار ریسک ۱۵٪ (محافظت فعال)",
                        color = SlateMuted,
                        fontSize = 9.sp
                    )
                }

                Button(
                    onClick = onExit,
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 2.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BearishRed.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .height(28.dp)
                        .border(1.dp, BearishRed.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                        .testTag("exit_position_btn")
                ) {
                    Text(text = "بستن تسویه", color = BearishRed, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
