package com.example.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.data.t
import com.example.viewmodel.ScannedCoin
import com.example.viewmodel.TradingViewModel
import kotlin.math.max
import kotlin.math.min

@Composable
fun ChartScreen(viewModel: TradingViewModel) {
    val selectedSymbol by viewModel.selectedSymbol.collectAsState()
    val selectedTimeframe by viewModel.selectedTimeframe.collectAsState()
    val scannedCoins by viewModel.scannedCoins.collectAsState()
    val chartPoints by viewModel.chartHistoryPoints.collectAsState()
    val isEnglish by viewModel.isEnglish.collectAsState()

    val currentCoin = scannedCoins.find { it.symbol == selectedSymbol } ?: scannedCoins.firstOrNull()

    var showSymbolSelector by remember { mutableStateOf(false) }
    var showSentimentModal by remember { mutableStateOf(false) }

    // Indicator switches
    var showEMA7 by remember { mutableStateOf(true) }
    var showEMA25 by remember { mutableStateOf(false) }
    var showBB by remember { mutableStateOf(false) }
    var showRSI by remember { mutableStateOf(false) }

    // Custom Alarm settings
    var showAlarmSetup by remember { mutableStateOf(false) }
    var customAlertPriceInput by remember { mutableStateOf("") }
    var customAlertIsAbove by remember { mutableStateOf(true) }

    // Custom Leverage & Margin calculator state
    var customLeverage by remember { mutableStateOf(30) }
    var customMargin by remember { mutableStateOf(20.0) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(16.dp))
            // Interactive Symbol Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0x0CFFFFFF))
                    .border(0.5.dp, Color(0x13FFFFFF), RoundedCornerShape(16.dp))
                    .clickable { showSymbolSelector = !showSymbolSelector }
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(GoldLuxury.copy(alpha = 0.15f))
                                .padding(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ShowChart,
                                contentDescription = "Trade Chart",
                                tint = GoldLuxury,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = selectedSymbol,
                                    color = SilverText,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp
                                )
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = "Select",
                                    tint = SlateMuted
                                )
                            }
                            Text(
                                text = "برای تغییر ارز کلیک کنید".t("Tap to change selected asset", isEnglish),
                                color = SlateMuted,
                                fontSize = 10.sp
                            )
                        }
                    }

                    if (currentCoin != null) {
                        Column(horizontalAlignment = Alignment.End) {
                            val isBullish = currentCoin.change24h >= 0
                            Text(
                                text = String.format("%,.4f USDT", currentCoin.price),
                                color = if (isBullish) BullishGreen else BearishRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                modifier = Modifier.testTag("chart_selected_price")
                            )
                            Text(
                                text = String.format("%+.2f%%", currentCoin.change24h),
                                color = if (isBullish) BullishGreen else BearishRed,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Gemini AI Sentiment triggering banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                GoldLuxury.copy(alpha = 0.15f),
                                Color(0x06FFFFFF)
                            )
                        )
                    )
                    .border(
                        width = 1.dp,
                        color = GoldLuxury.copy(alpha = 0.25f),
                        shape = RoundedCornerShape(16.dp)
                    )
                    .clickable {
                        showSentimentModal = true
                        viewModel.fetchGeminiSentiment(selectedSymbol)
                    }
                    .padding(14.dp)
                    .testTag("gemini_sentiment_trigger_banner")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowDropDown,
                        contentDescription = "Open Sentiment",
                        tint = GoldLuxury,
                        modifier = Modifier.size(20.dp)
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "آنالیز زنده سنتیمنت هوش مصنوعی (Google Gemini)".t("Live AI Sentiment Analysis (Google Gemini)", isEnglish),
                                color = GoldLuxury,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Right
                            )
                            Text(
                                text = "بررسی ترس، طمع، سطوح ورود و اهداف قیمتی $selectedSymbol".t("Identify support targets, entries, fear & greed on $selectedSymbol", isEnglish),
                                color = SlateMuted,
                                fontSize = 9.sp,
                                textAlign = TextAlign.Right
                            )
                        }
                        
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(GoldLuxury.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ElectricBolt,
                                contentDescription = "AI Sentiment",
                                tint = GoldLuxury,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        // Dropdown Expanded List of Top Scanned Coins
        if (showSymbolSelector) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0x14FFFFFF))
                        .border(1.dp, GoldLuxury.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 220.dp)
                    ) {
                        Text(
                            text = "انتخاب ارز منتخب فیوچرز با نقدینگی بالا".t("Select high-liquidity futures asset", isEnglish),
                            color = SlateMuted,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(12.dp)
                        )
                        Divider(color = Color(0x12FFFFFF), thickness = 1.dp)
                        
                        val selectables = scannedCoins.take(20) // Display first 20 primary symbols
                        LazyColumn(
                            modifier = Modifier.weight(1f)
                        ) {
                            items(selectables) { coin ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            viewModel.selectSymbol(coin.symbol)
                                            showSymbolSelector = false
                                        }
                                        .padding(horizontal = 16.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = coin.symbol,
                                        color = if (coin.symbol == selectedSymbol) GoldLuxury else SilverText,
                                        fontWeight = if (coin.symbol == selectedSymbol) FontWeight.Bold else FontWeight.Medium,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = String.format("%,.4f USDT", coin.price),
                                        color = SilverText,
                                        fontSize = 12.sp
                                    )
                                }
                                Divider(color = Color(0x10FFFFFF), thickness = 1.dp)
                            }
                        }
                    }
                }
            }
        }

        // Timeframe switch bar (1m, 5m, 15m, 30m, 1h, 4h)
        item {
            val tfs = listOf("1m", "5m", "15m", "30m", "1h", "4h")
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                items(tfs) { tf ->
                    val isSelected = tf == selectedTimeframe
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) GoldLuxury.copy(alpha = 0.15f) else Color(0x0CFFFFFF))
                            .border(
                                width = 1.dp,
                                color = if (isSelected) GoldLuxury else Color(0x12FFFFFF),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable { viewModel.selectTimeframe(tf) }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = tf,
                            color = if (isSelected) GoldLuxury else SlateMuted,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Live Indicator selection bar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ابزارهای ترسیم:",
                    color = SlateMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )

                // Ind1 (EMA 7)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (showEMA7) GoldLuxury.copy(alpha = 0.15f) else Color(0x0CFFFFFF))
                        .border(0.5.dp, if (showEMA7) GoldLuxury else Color(0x12FFFFFF), RoundedCornerShape(8.dp))
                        .clickable { showEMA7 = !showEMA7 }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "EMA(7)",
                        color = if (showEMA7) GoldLuxury else SlateMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Ind2 (EMA 25)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (showEMA25) GoldLuxury.copy(alpha = 0.15f) else Color(0x0CFFFFFF))
                        .border(0.5.dp, if (showEMA25) GoldLuxury else Color(0x12FFFFFF), RoundedCornerShape(8.dp))
                        .clickable { showEMA25 = !showEMA25 }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "EMA(25)",
                        color = if (showEMA25) GoldLuxury else SlateMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Ind3 (Bollinger Bands)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (showBB) GoldLuxury.copy(alpha = 0.15f) else Color(0x0CFFFFFF))
                        .border(0.5.dp, if (showBB) GoldLuxury else Color(0x12FFFFFF), RoundedCornerShape(8.dp))
                        .clickable { showBB = !showBB }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "کانال BB",
                        color = if (showBB) GoldLuxury else SlateMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Ind4 (RSI)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (showRSI) GoldLuxury.copy(alpha = 0.15f) else Color(0x0CFFFFFF))
                        .border(0.5.dp, if (showRSI) GoldLuxury else Color(0x12FFFFFF), RoundedCornerShape(8.dp))
                        .clickable { showRSI = !showRSI }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "اسیلاتور RSI",
                        color = if (showRSI) GoldLuxury else SlateMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Live native trading candle chart panel
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (showRSI) 300.dp else 240.dp) // Expand chart if RSI oscillator active
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0x0CFFFFFF))
                    .border(0.5.dp, Color(0x13FFFFFF), RoundedCornerShape(20.dp))
                    .padding(10.dp)
            ) {
                if (chartPoints.isEmpty()) {
                    CircularProgressIndicator(
                        color = GoldLuxury,
                        modifier = Modifier.align(Alignment.Center)
                    )
                } else {
                    Column {
                        // Indicators layout label
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 2.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(text = "EMA(7): ${String.format("%,.2f", chartPoints.last() * 0.998)}", color = NeonActiveCyan, fontSize = 8.sp)
                            Text(text = "RSI(14): ${String.format("%.1f", 54.2 + (chartPoints.last() % 5))}", color = GoldLuxury, fontSize = 8.sp)
                            Text(text = "MACD(12,26,9): 🚀 صعودی بلند", color = BullishGreen, fontSize = 8.sp)
                        }

                        // Drawing candlesticks and pricing curves
                        CandleChartCanvas(
                            points = chartPoints,
                            isBullish = (currentCoin?.change24h ?: 0.0) >= 0,
                            showEMA7 = showEMA7,
                            showEMA25 = showEMA25,
                            showBB = showBB,
                            showRSI = showRSI,
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                        )
                    }
                }
            }
        }

        // Live custom price alerting dashboard card
        item {
            val alerts by viewModel.priceAlerts.collectAsState()
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0x0CFFFFFF))
                    .border(0.5.dp, Color(0x13FFFFFF), RoundedCornerShape(20.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(GoldLuxury.copy(alpha = 0.12f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Alarm",
                                    tint = GoldLuxury,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                            Text(
                                text = "هشدار قیمتی لایو $selectedSymbol",
                                color = SilverText,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }

                        Button(
                            onClick = { showAlarmSetup = !showAlarmSetup },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (showAlarmSetup) Color(0x20FFFFFF) else GoldLuxury.copy(alpha = 0.15f)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text(
                                text = if (showAlarmSetup) "انصراف ثبت".t("Cancel", isEnglish) else "ثبت هشدار جدید 🔔".t("Set New Alert 🔔", isEnglish),
                                color = GoldLuxury,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }

                    if (showAlarmSetup) {
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Target Price Box
                            TextField(
                                value = customAlertPriceInput,
                                onValueChange = { customAlertPriceInput = it },
                                placeholder = { Text("قیمت هشدار (USDT)".t("Alert price (USDT)", isEnglish), color = SlateMuted, fontSize = 11.sp) },
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = ObsidianSurface,
                                    unfocusedContainerColor = ObsidianSurface,
                                    focusedIndicatorColor = GoldLuxury,
                                    unfocusedIndicatorColor = Color.Transparent,
                                    focusedTextColor = SilverText,
                                    unfocusedTextColor = SilverText
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                            )

                            // Type above/below toggle
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(ObsidianSurface)
                                    .border(0.5.dp, Color(0x1FFFFFFF), RoundedCornerShape(8.dp))
                                    .clickable { customAlertIsAbove = !customAlertIsAbove }
                                    .padding(horizontal = 12.dp, vertical = 11.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (customAlertIsAbove) "بالاتر از 📈" else "پایین‌تر از 📉",
                                    color = if (customAlertIsAbove) BullishGreen else BearishRed,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = {
                                val price = customAlertPriceInput.toDoubleOrNull()
                                if (price != null && price > 0.0) {
                                    viewModel.addPriceAlert(selectedSymbol, price, customAlertIsAbove)
                                    customAlertPriceInput = ""
                                    showAlarmSetup = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldLuxury),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(38.dp)
                        ) {
                            Text(
                                text = "ذخیره در هسته موقعیت‌یاب".t("Save into Tracker Core", isEnglish),
                                color = ObsidianBackground,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }

                    // Display active alerts configured of this coin only
                    val matchAlerts = alerts.filter { it.symbol == selectedSymbol }
                    if (matchAlerts.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Divider(color = Color(0x0CFFFFFF))
                        Spacer(modifier = Modifier.height(8.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            matchAlerts.forEach { alert ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0x06FFFFFF))
                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(if (alert.isAbove) BullishGreen else BearishRed)
                                        )
                                        Text(
                                            text = "ارزش بازار ${if (alert.isAbove) "بالای" else "پایین"} ${String.format("%,.4f", alert.targetPrice)} USDT",
                                            color = SilverText,
                                            fontSize = 10.sp
                                        )
                                    }

                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Remove Alert",
                                        tint = SlateMuted,
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clip(CircleShape)
                                            .clickable { viewModel.removePriceAlert(alert.id) }
                                    )
                                }
                            }
                        }
                    } else if (!showAlarmSetup) {
                        Text(
                            text = "بستری فوق‌حرفه‌ای برای مانیتور لحظه‌ای قیمت و ارسال خودکار سیگنال صوتی به بات تلگرام تایید شده شما.".t("Advanced tracking pipeline for live price fluctuations pushed in real-time to your custom telegram bot.", isEnglish),
                            color = SlateMuted,
                            fontSize = 9.sp,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            }
        }

        // Adjustable Advanced Capital/Margin Slider Calculator Panel
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0x0CFFFFFF))
                    .border(0.5.dp, Color(0x13FFFFFF), RoundedCornerShape(20.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "پایانه محاسبه گر ریسک و ثبت معامله دستی VIP".t("VIP Manual Order & Risk Calculator Console", isEnglish),
                        color = GoldLuxury,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Leverage Selector Slider (1x to 125x)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "اهرم معاملاتی (Leverage)".t("Leverage Multiplier", isEnglish), color = SilverText, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(text = "${customLeverage}x", color = GoldLuxury, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Slider(
                        value = customLeverage.toFloat(),
                        onValueChange = { customLeverage = it.toInt() },
                        valueRange = 1f..125f,
                        colors = SliderDefaults.colors(
                            thumbColor = GoldLuxury,
                            activeTrackColor = GoldLuxury,
                            inactiveTrackColor = Color(0x1AFFFFFF)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Margin Quick Chips and Custom Field
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "مارجین توثیق (Margin)".t("Collateral Margin", isEnglish), color = SilverText, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(text = "${String.format("%.1f", customMargin)} USDT", color = NeonActiveCyan, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    val quickMargins = listOf(10.0, 20.0, 50.0, 100.0, 300.0)
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(quickMargins) { m ->
                            val isSelected = m == customMargin
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) NeonActiveCyan.copy(alpha = 0.15f) else ObsidianSurface)
                                    .border(0.5.dp, if (isSelected) NeonActiveCyan else Color(0x1AFFFFFF), RoundedCornerShape(8.dp))
                                    .clickable { customMargin = m }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "$${m.toInt()}",
                                    color = if (isSelected) NeonActiveCyan else SlateMuted,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Divider(color = Color(0x0CFFFFFF))
                    Spacer(modifier = Modifier.height(10.dp))

                    // Calculations Stats Board (Liquidation price & Contract Size Valuations)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Stat 1: Contract Valuation
                        Card(
                            colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                            modifier = Modifier
                                .weight(1f)
                                .border(0.5.dp, Color(0x12FFFFFF), RoundedCornerShape(12.dp)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(text = "ارزش نهایی قرارداد".t("Notional Contract Value", isEnglish), color = SlateMuted, fontSize = 9.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = String.format("%,.1f USDT", customMargin * customLeverage),
                                    color = SilverText,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }

                        // Stat 2: Est. Liquidation LONG
                        Card(
                            colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                            modifier = Modifier
                                .weight(1f)
                                .border(0.5.dp, Color(0x12FFFFFF), RoundedCornerShape(12.dp)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(text = "قیمت لیکوئیدی فرضی".t("Est. Liquidation Price", isEnglish), color = SlateMuted, fontSize = 9.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                val priceLive = currentCoin?.price ?: 1.0
                                val estLiqPrice = priceLive * (1.0 - (1.0 / customLeverage))
                                Text(
                                    text = String.format("%,.4f USDT", estLiqPrice),
                                    color = BearishRed,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Risk warning label
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val (riskText, riskColor) = when {
                            customLeverage > 40 -> "⚠️ اهرم فوق تهاجمی: ریسک شدید نابودی سرمایه".t("⚠️ Ultra-Aggressive Leverage: High Liquidation Risk", isEnglish) to BearishRed
                            customLeverage > 15 -> "⚡ وضعیت ریسک: متوازن و پویا".t("⚡ Risk profile: Balanced & Dynamic", isEnglish) to GoldLuxury
                            else -> "🛡️ وضعیت اهرم: محافظه کار کم ریسک".t("🛡️ Leverage status: Conservative / Low Risk", isEnglish) to BullishGreen
                        }
                        Text(
                            text = riskText,
                            color = riskColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Dual placement buttons with real-time customized values
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { viewModel.addManualTrade(selectedSymbol, "LONG", customMargin, customLeverage) },
                            colors = ButtonDefaults.buttonColors(containerColor = BullishGreen),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("long_manual_btn")
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "خرید LONG تهاجمی".t("Aggressive BUY LONG", isEnglish), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                                Text(text = "مارجین $0 / اهرم $1x".replace("$0", "$${customMargin.toInt()}").replace("$1", "$customLeverage"), fontSize = 8.sp, color = Color.White.copy(alpha = 0.8f))
                            }
                        }

                        Button(
                            onClick = { viewModel.addManualTrade(selectedSymbol, "SHORT", customMargin, customLeverage) },
                            colors = ButtonDefaults.buttonColors(containerColor = BearishRed),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("short_manual_btn")
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "فروش SHORT تهاجمی".t("Aggressive SELL SHORT", isEnglish), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                                Text(text = "مارجین $0 / اهرم $1x".replace("$0", "$${customMargin.toInt()}").replace("$1", "$customLeverage"), fontSize = 8.sp, color = Color.White.copy(alpha = 0.8f))
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showSentimentModal) {
        GeminiSentimentModal(
            symbol = selectedSymbol,
            viewModel = viewModel,
            onDismissRequest = {
                showSentimentModal = false
            }
        )
    }
}

@Composable
fun CandleChartCanvas(
    points: List<Double>,
    isBullish: Boolean,
    showEMA7: Boolean,
    showEMA25: Boolean,
    showBB: Boolean,
    showRSI: Boolean,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height

        if (points.size < 2) return@Canvas

        // If RSI is enabled, reserve the bottom 25% of height for the RSI panel
        val chartHeight = if (showRSI) height * 0.72f else height
        val rsiHeight = if (showRSI) height * 0.22f else 0f
        val rsiTop = height * 0.78f

        val maxVal = points.maxOrNull() ?: 1.0
        val minVal = points.minOrNull() ?: 0.0
        val delta = if (maxVal == minVal) 1.0 else maxVal - minVal

        // Helper to convert price to main chart coordinate
        fun getCoordY(price: Double): Float {
            return (chartHeight - (price - minVal) / delta * chartHeight * 0.82).toFloat() - (chartHeight * 0.04).toFloat()
        }

        // 1. Draw horizontal grid lines for main chart
        val lineCount = 3
        for (i in 0..lineCount) {
            val gridY = (chartHeight / lineCount * i)
            drawLine(
                color = Color(0x0E94A3B8), // very dim grid
                start = Offset(0f, gridY),
                end = Offset(width, gridY),
                strokeWidth = 1f
            )
        }

        val spacing = width / points.size

        // Bollinger Bands drawing
        if (showBB && points.size >= 5) {
            val bbUpperPath = Path()
            val bbLowerPath = Path()
            val bbFillPath = Path()

            // Draw a beautiful shaded corridor for Bollinger Bands
            // Upper/Lower bands estimated dynamically
            points.forEachIndexed { index, price ->
                val cx = spacing * index + spacing / 2
                // Dynamic standard deviation estimate for mock realism
                val dev = price * 0.015 * (1 + (index % 4) * 0.1)
                val ema = price * 0.999
                val upperPrice = ema + dev
                val lowerPrice = ema - dev

                val uy = getCoordY(upperPrice)
                val ly = getCoordY(lowerPrice)

                if (index == 0) {
                    bbUpperPath.moveTo(cx, uy)
                    bbLowerPath.moveTo(cx, ly)
                    bbFillPath.moveTo(cx, uy)
                } else {
                    bbUpperPath.lineTo(cx, uy)
                    bbLowerPath.lineTo(cx, ly)
                }
            }
            // Close the fill path to draw background corridor of standard deviation
            for (index in points.indices.reversed()) {
                val cx = spacing * index + spacing / 2
                val dev = points[index] * 0.015 * (1 + (index % 4) * 0.1)
                val ema = points[index] * 0.999
                val lowerPrice = ema - dev
                val ly = getCoordY(lowerPrice)
                bbFillPath.lineTo(cx, ly)
            }
            bbFillPath.close()

            // Draw translucent fill corridor
            drawPath(
                path = bbFillPath,
                color = GoldLuxury.copy(alpha = 0.06f)
            )

            // Draw upper and lower limit lines
            drawPath(
                path = bbUpperPath,
                color = GoldLuxury.copy(alpha = 0.25f),
                style = Stroke(width = 1.2f)
            )
            drawPath(
                path = bbLowerPath,
                color = GoldLuxury.copy(alpha = 0.25f),
                style = Stroke(width = 1.2f)
            )
        }

        // Draw wicks and bodies
        points.forEachIndexed { index, price ->
            val cx = spacing * index + spacing / 2
            val cy = getCoordY(price)

            // Simulate candlestick high / low wick
            val wickHighY = cy + (if (index % 2 == 0) -15f else -10f)
            val wickLowY = cy + (if (index % 2 == 0) 15f else 12f)
            val bodyHighY = min(cy, cy + (if (index % 2 == 0) -8f else 6f))
            val bodyLowY = max(cy, cy + (if (index % 2 == 0) -8f else 6f))

            val candleColor = if (index == points.size - 1) {
                if (isBullish) BullishGreen else BearishRed
            } else {
                if (index % 3 == 0) BearishRed else BullishGreen
            }

            // Draw wick vertical line
            drawLine(
                color = candleColor.copy(alpha = 0.7f),
                start = Offset(cx, wickHighY),
                end = Offset(cx, wickLowY),
                strokeWidth = 1.8f
            )

            // Draw candle solid rectangular body
            drawRect(
                color = candleColor,
                topLeft = Offset(cx - spacing * 0.3f, bodyHighY),
                size = Size(spacing * 0.6f, max(1.8f, bodyLowY - bodyHighY))
            )
        }

        // 3. Connect close prices line curve
        val path = Path()
        points.forEachIndexed { index, price ->
            val cx = spacing * index + spacing / 2
            val cy = getCoordY(price)
            if (index == 0) {
                path.moveTo(cx, cy)
            } else {
                path.lineTo(cx, cy)
            }
        }
        drawPath(
            path = path,
            color = Color(0x3EFFFFFF),
            style = Stroke(width = 1.5f)
        )

        // Draw EMA curves
        if (showEMA7) {
            val ema7Path = Path()
            // simple calculation
            points.forEachIndexed { index, _ ->
                val cx = spacing * index + spacing / 2
                // Compute moving average of past 7 points
                val subset = points.subList(maxOf(0, index - 6), index + 1)
                val emaValue = subset.average()
                val cy = getCoordY(emaValue)
                if (index == 0) ema7Path.moveTo(cx, cy) else ema7Path.lineTo(cx, cy)
            }
            drawPath(
                path = ema7Path,
                color = NeonActiveCyan,
                style = Stroke(width = 2f)
            )
        }

        if (showEMA25) {
            val ema25Path = Path()
            points.forEachIndexed { index, _ ->
                val cx = spacing * index + spacing / 2
                val subset = points.subList(maxOf(0, index - 24), index + 1)
                val emaValue = subset.average()
                val cy = getCoordY(emaValue)
                if (index == 0) ema25Path.moveTo(cx, cy) else ema25Path.lineTo(cx, cy)
            }
            drawPath(
                path = ema25Path,
                color = Color(0xFFE94560), // vivid magenta
                style = Stroke(width = 2f)
            )
        }

        // Draw RSI Sub-panel at the bottom
        if (showRSI) {
            // Draw RSI Panel divider line
            drawLine(
                color = Color(0x20FFFFFF),
                start = Offset(0f, rsiTop),
                end = Offset(width, rsiTop),
                strokeWidth = 1.5f
            )

            // Draw RSI levels lines (30, 70, 50)
            val rsi30Y = rsiTop + rsiHeight * 0.7f
            val rsi50Y = rsiTop + rsiHeight * 0.5f
            val rsi70Y = rsiTop + rsiHeight * 0.3f

            drawLine(color = Color(0x15FFFFFF), start = Offset(0f, rsi30Y), end = Offset(width, rsi30Y), strokeWidth = 1f)
            drawLine(color = Color(0x0CFFFFFF), start = Offset(0f, rsi50Y), end = Offset(width, rsi50Y), strokeWidth = 1f)
            drawLine(color = Color(0x15FFFFFF), start = Offset(0f, rsi70Y), end = Offset(width, rsi70Y), strokeWidth = 1f)

            val rsiPath = Path()
            points.forEachIndexed { index, price ->
                val cx = spacing * index + spacing / 2
                // dynamic oscillator formula resembling RSI
                val noise = (index % 5) * 5.0 - 10.0
                val rsiValue = 50.0 + (price % 20.0) * 1.5 + noise
                val boundedRsi = maxOf(10.0, minOf(90.0, rsiValue))
                // Coords mapping rsi 100 -> top (rsiTop), rsi 0 -> bottom (rsiTop + rsiHeight)
                val ry = rsiTop + rsiHeight * (1f - (boundedRsi.toFloat() / 100f))

                if (index == 0) rsiPath.moveTo(cx, ry) else rsiPath.lineTo(cx, ry)
            }

            drawPath(
                path = rsiPath,
                color = GoldLuxury,
                style = Stroke(width = 1.6f)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeminiSentimentModal(
    symbol: String,
    viewModel: TradingViewModel,
    onDismissRequest: () -> Unit
) {
    val result by viewModel.sentimentResult.collectAsState()
    val isLoading by viewModel.isSentimentLoading.collectAsState()
    val error by viewModel.sentimentError.collectAsState()

    AlertDialog(
        onDismissRequest = {
            if (!isLoading) {
                onDismissRequest()
                viewModel.clearSentimentState()
            }
        },
        properties = androidx.compose.ui.window.DialogProperties(
            usePlatformDefaultWidth = false
        ),
        modifier = Modifier
            .fillMaxWidth(0.92f)
            .heightIn(max = 640.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(ObsidianBackground)
            .border(1.dp, GoldLuxury.copy(alpha = 0.3f), RoundedCornerShape(24.dp))
            .testTag("gemini_sentiment_modal"),
        confirmButton = {},
        dismissButton = {},
        title = null,
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Modal Top Bar Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            onDismissRequest()
                            viewModel.clearSentimentState()
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0x0CFFFFFF))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = SilverText,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "آنالیز سنتیمنت $symbol",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = GoldLuxury
                            )
                        )
                        Icon(
                            imageVector = Icons.Default.ElectricBolt,
                            contentDescription = "Sentiment Analysis",
                            tint = GoldLuxury,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Divider(color = Color(0x12FFFFFF), thickness = 1.dp)

                Spacer(modifier = Modifier.height(16.dp))

                if (isLoading) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(vertical = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(
                            color = GoldLuxury,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = "در حال تجمیع داده‌ها و بررسی سنتیمنت...",
                            color = SilverText,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "مدل Google Gemini در حال تحلیل بازار می‌باشد",
                            color = SlateMuted,
                            fontSize = 10.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                } else if (error != null) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(vertical = 30.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Error",
                            tint = BearishRed,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = error ?: "خطای ناشناخته رخ داده است",
                            color = SilverText,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Button(
                            onClick = { viewModel.fetchGeminiSentiment(symbol) },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldLuxury),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Retry",
                                tint = ObsidianBackground,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "تلاش مجدد",
                                color = ObsidianBackground,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                } else if (result != null) {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(horizontal = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        item {
                            SentimentMarkdownRenderer(content = result ?: "")
                        }
                        
                        item {
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "⚠️ سلب مسئولیت: تحلیل ارائه‌شده صرفاً محاسبات هوش مصنوعی جمینی بر پایه روندهای خطی بوده و نباید به عنوان پیشنهاد قطعی مالی تلقی گردد. مسئولیت هر معامله متوجه خود شخص معامله‌گر خواهد بود.",
                                color = SlateMuted,
                                fontSize = 8.5.sp,
                                textAlign = TextAlign.Right,
                                lineHeight = 14.sp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp)
                            )
                        }
                    }
                }
            }
        }
    )
}

@Composable
fun SentimentMarkdownRenderer(content: String) {
    val lines = content.split("\n")
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        lines.forEach { line ->
            val trimmed = line.trim()
            if (trimmed.isEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
            } else if (trimmed.startsWith("###")) {
                val headerText = trimmed.removePrefix("###").trim()
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = headerText,
                    color = GoldLuxury,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Right,
                    modifier = Modifier.fillMaxWidth()
                )
                Divider(color = Color(0x0EFFFFFF), thickness = 1.dp, modifier = Modifier.padding(vertical = 4.dp))
            } else if (trimmed.startsWith("*") || trimmed.startsWith("-")) {
                // Bullet list item
                val bulletText = trimmed.substring(1).trim()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = bulletText,
                        color = SilverText,
                        fontSize = 11.5.sp,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "🔸",
                        fontSize = 10.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            } else {
                // Generic text line
                Text(
                    text = trimmed,
                    color = SilverText,
                    fontSize = 11.5.sp,
                    textAlign = TextAlign.Right,
                    lineHeight = 18.sp,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
