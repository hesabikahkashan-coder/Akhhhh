package com.example.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.NewsItem
import com.example.viewmodel.ScannedCoin
import com.example.viewmodel.TradingViewModel
import com.example.data.t

@Composable
fun IntelligenceScreen(viewModel: TradingViewModel) {
    val newsFeed by viewModel.newsFeed.collectAsState()
    val grokPred by viewModel.grokPrediction.collectAsState()
    val grokConfidence by viewModel.grokConfidence.collectAsState()
    val grokDir by viewModel.grokDirection.collectAsState()
    val grokDumpWarning by viewModel.grokDumpDanger.collectAsState()
    val newListings by viewModel.newListings.collectAsState()
    val hotMovers by viewModel.hotMovers.collectAsState()
    val aiStatusMessage by viewModel.aiStatusMessage.collectAsState()
    val isEnglish by viewModel.isEnglish.collectAsState()

    var activeSubTab by remember { mutableStateOf("AI_PREDICT") } // AI_PREDICT, NEW_LISTINGS, NEWS_FEED

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(16.dp))
            // Dashboard Intelligent Screen Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "مرکز هوش مصنوعی & آنالایزر".t("AI Intelligence Center & Analyser", isEnglish),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = GoldLuxury
                        )
                    )
                    Text(
                        text = "پیش‌بینی‌های زنده هوش مصنوعی با کمک مدل‌های لارج".t("Real-time AI estimations fueled by LLM metrics", isEnglish),
                        color = SlateMuted,
                        fontSize = 11.sp
                    )
                }

                // AI Refresh Action Button
                IconButton(
                    onClick = { viewModel.refreshAiIntelligence() },
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(ObsidianSurface)
                        .border(0.5.dp, GoldLuxury.copy(alpha = 0.35f), CircleShape)
                        .testTag("refresh_ai_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh",
                        tint = GoldLuxury,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Displaying current active background connection state of the model
        if (aiStatusMessage.isNotEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(ObsidianSurface)
                        .border(0.5.dp, ObsidianContainer, RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = aiStatusMessage,
                        color = GoldLuxury,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Sub Navigation Menu
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(ObsidianSurface)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf(
                    "AI_PREDICT" to "پیش‌بینی Grok".t("Grok AI Prediction", isEnglish),
                    "NEW_LISTINGS" to "ارزهای نوظهور".t("Emerging Tokens", isEnglish),
                    "NEWS_FEED" to "اخبار و تفسیر AI".t("AI Intelligence News", isEnglish)
                ).forEach { (key, title) ->
                    val isSelected = key == activeSubTab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) GoldLuxury.copy(alpha = 0.15f) else Color.Transparent)
                            .clickable { activeSubTab = key }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = title,
                            color = if (isSelected) GoldLuxury else SlateMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Dynamic Sub-Panel layouts
        when (activeSubTab) {
            "AI_PREDICT" -> {
                // Selectable Groq Model Chips
                item {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Text(
                            text = "مدل محاسباتی فعال Groq".t("Active Groq LLM Inference Model", isEnglish),
                            color = SlateMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        
                        val activeModel by viewModel.selectedModel.collectAsState()
                        val groqModels = listOf(
                            "llama-3.1-8b-instant" to "Llama 3.1 8B",
                            "meta-llama/llama-4-scout-17b-16e-instruct" to "Llama 4 Scout",
                            "llama-3.3-70b-versatile" to "Llama 3.3 70B",
                            "whisper-large-v3-turbo" to "Whisper Turbo"
                        )
                        
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(groqModels) { (modelId, displayName) ->
                                val isSelected = activeModel == modelId
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) GoldLuxury.copy(alpha = 0.15f) else ObsidianSurface)
                                        .border(
                                            width = 1.dp,
                                            color = if (isSelected) GoldLuxury else Color(0x12FFFFFF),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .clickable { viewModel.selectModel(modelId) }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = displayName,
                                        color = if (isSelected) GoldLuxury else SlateMuted,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // Grok AI Pred Panel
                item {
                    GrokPredictorCard(
                        predictionText = grokPred,
                        confidence = grokConfidence,
                        direction = grokDir,
                        dumpWarning = grokDumpWarning,
                        isEnglish = isEnglish
                    )
                }

                // Volume Spikers / Hot Movers
                item {
                    Text(
                        text = "سیگنال شتاب‌دهنده جهش نوسان (Hot Movers)".t("Momentum Volatility Alerts (Hot Movers)", isEnglish),
                        fontWeight = FontWeight.Bold,
                        color = SilverText,
                        fontSize = 13.sp
                    )
                }

                if (hotMovers.isEmpty()) {
                    item {
                        Text(text = "در حال تحلیل شتاب کوین‌ها...".t("Analyzing market momentum parameters...", isEnglish), color = SlateMuted, fontSize = 11.sp)
                    }
                } else {
                    items(hotMovers) { coin ->
                        HotMoversRow(coin, isEnglish)
                    }
                }
            }

            "NEW_LISTINGS" -> {
                // Listings headers
                item {
                    Text(
                        text = "رادار توکن‌های تازه لیست‌شده & لانچ‌پول بایننس".t("Binance Launchpool & Emerging Token Radar", isEnglish),
                        fontWeight = FontWeight.Bold,
                        color = SilverText,
                        fontSize = 13.sp
                    )
                }

                if (newListings.isEmpty()) {
                    item {
                        Text(text = "رادار در حال اسکن توکن‌های تازه...".t("Launch tracker scanning for newly deployed contracts...", isEnglish), color = SlateMuted, fontSize = 11.sp)
                    }
                } else {
                    items(newListings) { coin ->
                        NewListingCard(coin, isEnglish)
                    }
                }
            }

            "NEWS_FEED" -> {
                item {
                    Text(
                        text = "تحلیل خلاصه خبر رسانه‌های متبوع به فارسی روان".t("Bilingual AI Market Sentiment News coverage summaries", isEnglish),
                        fontWeight = FontWeight.Bold,
                        color = SilverText,
                        fontSize = 13.sp
                    )
                }

                if (newsFeed.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "اخبار جدید دریافت نشد. دکمه رفرش را فشار دهید.".t("Failed to look up news. Tap the refresh button above.", isEnglish), color = SlateMuted, fontSize = 12.sp)
                        }
                    }
                } else {
                    items(newsFeed) { news ->
                        NewsIntelRow(news, isEnglish)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun GrokPredictorCard(
    predictionText: String,
    confidence: Int,
    direction: String,
    dumpWarning: Boolean,
    isEnglish: Boolean
) {
    val isLONG = direction == "LONG"

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0x1BFFFFFF), Color(0x05FFFFFF))
                )
            )
            .border(
                width = 1.dp,
                color = Color(0x1AFFFFFF),
                shape = RoundedCornerShape(24.dp)
            )
            .padding(20.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(GoldLuxury.copy(alpha = 0.15f))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "Grok AI",
                            color = GoldLuxury,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "پیش‌بینی الگو و روند فعلی بازار".t("Market pattern and trend prediction", isEnglish),
                        color = SilverText,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isLONG) BullishGreen.copy(alpha = 0.15f) else BearishRed.copy(alpha = 0.15f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isLONG) "روند LONG".t("BULLISH LONG", isEnglish) else "روند SHORT".t("BEARISH SHORT", isEnglish),
                        color = if (isLONG) BullishGreen else BearishRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Divider(color = Color(0x15FFFFFF), thickness = 1.dp)
            Spacer(modifier = Modifier.height(14.dp))

            // Prediction terminal body text
            Text(
                text = predictionText,
                color = SilverText,
                fontSize = 12.sp,
                lineHeight = 18.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Sub grid info: Confidence bar & Danger warnings
            Row(modifier = Modifier.fillMaxWidth()) {
                val accent = if (isLONG) BullishGreen else BearishRed
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(0.9f),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "درجه اطمینان سیگنال".t("Confidence Score", isEnglish), color = SlateMuted, fontSize = 9.sp)
                        Text(text = "$confidence%", color = GoldLuxury, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = confidence / 100f,
                        color = accent,
                        trackColor = Color(0x12FFFFFF),
                        modifier = Modifier
                            .fillMaxWidth(0.9f)
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp))
                    )
                }

                Divider(
                    color = Color(0x15FFFFFF),
                    modifier = Modifier
                        .height(30.dp)
                        .width(1.dp)
                )
                Spacer(modifier = Modifier.width(14.dp))

                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(text = "خطر دامپ ناگهانی (فروش شدید)".t("Sudden Dump Danger (Panic Selling)", isEnglish), color = SlateMuted, fontSize = 9.sp)
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (dumpWarning) Icons.Default.Warning else Icons.Default.CheckCircle,
                            contentDescription = "Danger Status",
                            tint = if (dumpWarning) WarnAmber else BullishGreen,
                            modifier = Modifier.size(11.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (dumpWarning) "🚨 با احتیاط حداکثر".t("🚨 Precautionary risk level", isEnglish) else "🟢 بدون تخلیه نقدینگی".t("🟢 Secure liquidity state", isEnglish),
                            color = if (dumpWarning) WarnAmber else BullishGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HotMoversRow(coin: ScannedCoin, isEnglish: Boolean) {
    val isBullish = coin.change24h >= 0

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x0CFFFFFF))
            .border(0.5.dp, Color(0x13FFFFFF), RoundedCornerShape(14.dp))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(if (isBullish) BullishGreen.copy(alpha = 0.15f) else BearishRed.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isBullish) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                        contentDescription = "Trend Direction",
                        tint = if (isBullish) BullishGreen else BearishRed,
                        modifier = Modifier.size(14.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = coin.symbol, color = SilverText, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(text = "مومنتوم شدید جهشی".t("High acceleration momentum", isEnglish), color = SlateMuted, fontSize = 9.sp)
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = String.format("%+.2f%%", coin.change24h),
                    color = if (isBullish) BullishGreen else BearishRed,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = "حجم: $0 USDT".replace("$0", String.format("%,.0f", coin.volume24h * 0.45)).t("Volume: $0 USDT".replace("$0", String.format("%,.0f", coin.volume24h * 0.45)), isEnglish),
                    color = SlateMuted,
                    fontSize = 8.sp
                )
            }
        }
    }
}

@Composable
fun NewListingCard(coin: ScannedCoin, isEnglish: Boolean) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x0CFFFFFF))
            .border(0.5.dp, Color(0x13FFFFFF), RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(WarnAmber.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "LAUNCHPOOL بایننس".t("BINANCE LAUNCHPOOL", isEnglish),
                            color = WarnAmber,
                            fontWeight = FontWeight.Bold,
                            fontSize = 8.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = coin.symbol.split("/").first(),
                        color = SilverText,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }

                Text(
                    text = "تازه لیست‌شده".t("Newly Listed", isEnglish),
                    color = SlateMuted,
                    fontSize = 10.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = Color(0x13FFFFFF), thickness = 1.dp)
            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "حجم مبادلات لانچ".t("Launch Pool Volume", isEnglish), color = SlateMuted, fontSize = 9.sp)
                    Text(
                        text = String.format("$ %,.0f", coin.volume24h),
                        color = SilverText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "رشد از زمان لانچ".t("Gains Since Deployment", isEnglish), color = SlateMuted, fontSize = 9.sp)
                    Text(
                        text = String.format("%+.1f%%", 120.0 + (coin.price * 23.0) % 300),
                        color = BullishGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(text = "زمان راه‌اندازی".t("Launch Time", isEnglish), color = SlateMuted, fontSize = 9.sp)
                    Text(text = "امروز صبح".t("This Morning", isEnglish), color = SilverText, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
fun NewsIntelRow(news: NewsItem, isEnglish: Boolean) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x0CFFFFFF))
            .border(0.5.dp, Color(0x13FFFFFF), RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = news.source,
                    color = GoldLuxury,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.sp
                )
                Text(
                    text = news.timeAgo,
                    color = SlateMuted,
                    fontSize = 8.sp
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            
            // Headline english first
            Text(
                text = news.originalHeadline,
                color = SlateMuted,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(6.dp))

            // AI summary farsi
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0x1A000000))
                    .padding(10.dp)
            ) {
                Text(
                    text = if (isEnglish) news.originalHeadline else news.persianSummary,
                    color = SilverText,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Sentiment impact badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "اثر احتمالی بر بازار: ".t("Est. Market Outlook: ", isEnglish), color = SlateMuted, fontSize = 10.sp)
                    Text(
                        text = news.impact.t(if (news.impact.contains("مثبت")) "🟢 Bullish Positive" else "🔴 Bearish Negligible", isEnglish),
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "شدت اثر: ".t("Severity Impact: ", isEnglish), color = SlateMuted, fontSize = 9.sp)
                    Text(text = "$0/۱۰".replace("$0", news.impactScore.toString()).t("${news.impactScore}/10", isEnglish), color = GoldLuxury, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                }
            }
        }
    }
}
