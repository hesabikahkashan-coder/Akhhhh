package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.random.Random

// Represents a real-time active simulated position
data class ActivePosition(
    val id: String = UUID.randomUUID().toString(),
    val symbol: String,
    val side: String, // LONG, SHORT
    val entryPrice: Double,
    var currentPrice: Double,
    val margin: Double = 20.0,
    val leverage: Int = 30,
    var maxPnlPercent: Double = 0.0,
    val openTime: Long = System.currentTimeMillis()
) {
    val pnlPercent: Double
        get() {
            val priceDiffPercent = (currentPrice - entryPrice) / entryPrice * 100
            return if (side == "LONG") {
                priceDiffPercent * leverage
            } else {
                -priceDiffPercent * leverage
            }
        }

    val pnlUsdt: Double
        get() = margin * (pnlPercent / 100)
}

// Represents scanned coins in Opportunity Scanner
data class ScannedCoin(
    val symbol: String,
    val price: Double,
    val minPrice: Double,
    val maxPrice: Double,
    val change24h: Double,
    val volatility: Double, // high, medium
    val score: Int,
    val probability: Int,
    val action: String, // LONG, SHORT, NEUTRAL
    val leverageAvailable: Int = 30,
    val isNewListings: Boolean = false,
    val volume24h: Double = Random.nextDouble(5000000.0, 95000000.0)
)

// Crypto News item
data class NewsItem(
    val title: String,
    val url: String,
    val source: String,
    val originalHeadline: String,
    val persianSummary: String,
    val impact: String, // 🟢 مثبت, 🔴 منفی, ⚪ خنثی
    val impactScore: Int, // 1 to 10
    val timeAgo: String
)

// Active custom price alerts
data class PriceAlert(
    val id: String = java.util.UUID.randomUUID().toString(),
    val symbol: String,
    val targetPrice: Double,
    val isAbove: Boolean,
    var isActive: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)

class TradingViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val tradeDao = db.tradeDao()
    private val alertDao = db.alertDao()

    // Language Toggle: Persian (Farsi) vs English
    private val _isEnglish = MutableStateFlow(false)
    val isEnglish: StateFlow<Boolean> = _isEnglish.asStateFlow()

    fun toggleLanguage() {
        _isEnglish.value = !_isEnglish.value
    }

    // Bot Active Toggle
    private val _isBotActive = MutableStateFlow(true)
    val isBotActive: StateFlow<Boolean> = _isBotActive.asStateFlow()

    // Active Custom Price Alerts
    private val _priceAlerts = MutableStateFlow<List<PriceAlert>>(emptyList())
    val priceAlerts: StateFlow<List<PriceAlert>> = _priceAlerts.asStateFlow()

    fun addPriceAlert(symbol: String, targetPrice: Double, isAbove: Boolean) {
        val newAlert = PriceAlert(
            symbol = symbol,
            targetPrice = targetPrice,
            isAbove = isAbove
        )
        _priceAlerts.value = _priceAlerts.value + newAlert
        viewModelScope.launch {
            insertAlert(
                "تنظیم هشدار قیمت",
                "هشدار قیمت برای $symbol در سطح $targetPrice USDT (${if (isAbove) "بالاتر" else "پایین‌تر"}) با موفقیت ثبت شد.",
                "INFO"
            )
        }
    }

    fun removePriceAlert(alertId: String) {
        val alert = _priceAlerts.value.find { it.id == alertId }
        _priceAlerts.value = _priceAlerts.value.filter { it.id != alertId }
        if (alert != null) {
            viewModelScope.launch {
                insertAlert(
                    "حذف هشدار قیمت",
                    "هشدار قیمت فرکانسی برای ${alert.symbol} لغو گردید.",
                    "INFO"
                )
            }
        }
    }

    // Mode Toggle: DEMO vs LIVE
    private val _isLiveMode = MutableStateFlow(false)
    val isLiveMode: StateFlow<Boolean> = _isLiveMode.asStateFlow()

    // Telegram Notifications Toggle
    private val _telegramNotificationsEnabled = MutableStateFlow(true)
    val telegramNotificationsEnabled: StateFlow<Boolean> = _telegramNotificationsEnabled.asStateFlow()

    fun toggleTelegramNotifications() {
        _telegramNotificationsEnabled.value = !_telegramNotificationsEnabled.value
    }

    // Balance & Account fields
    private val _accountBalance = MutableStateFlow(1000.0) // USDT initial
    val accountBalance: StateFlow<Double> = _accountBalance.asStateFlow()

    // API Connections Status Flows
    private val _binanceStatus = MutableStateFlow("بررسی...")
    val binanceStatus: StateFlow<String> = _binanceStatus.asStateFlow()

    private val _groqStatus = MutableStateFlow("بررسی...")
    val groqStatus: StateFlow<String> = _groqStatus.asStateFlow()

    private val _telegramStatus = MutableStateFlow("بررسی...")
    val telegramStatus: StateFlow<String> = _telegramStatus.asStateFlow()

    // Active Positions List
    private val _activePositions = MutableStateFlow<List<ActivePosition>>(emptyList())
    val activePositions: StateFlow<List<ActivePosition>> = _activePositions.asStateFlow()

    // Saved Trades History
    val tradeHistory: StateFlow<List<Trade>> = tradeDao.getAllTrades()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Alerts History
    val alertsList: StateFlow<List<Alert>> = alertDao.getAllAlerts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Scanned 150 select coins list (simulation of 30 main and rest secondary)
    private val _scannedCoins = MutableStateFlow<List<ScannedCoin>>(emptyList())
    val scannedCoins: StateFlow<List<ScannedCoin>> = _scannedCoins.asStateFlow()

    // Selected Symbol for live charts
    private val _selectedSymbol = MutableStateFlow("BTC/USDT")
    val selectedSymbol: StateFlow<String> = _selectedSymbol.asStateFlow()

    // Selected timeframe for charts
    private val _selectedTimeframe = MutableStateFlow("5m")
    val selectedTimeframe: StateFlow<String> = _selectedTimeframe.asStateFlow()

    // Top movers (Volume spikes or high change%)
    val hotMovers: StateFlow<List<ScannedCoin>> = _scannedCoins.map { list ->
        list.filter { it.volatility > 4.5 || Math.abs(it.change24h) > 5.0 }
            .sortedByDescending { Math.abs(it.change24h) }
            .take(6)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // New listings
    private val _newListings = MutableStateFlow<List<ScannedCoin>>(emptyList())
    val newListings: StateFlow<List<ScannedCoin>> = _newListings.asStateFlow()

    // News Intel
    private val _newsFeed = MutableStateFlow<List<NewsItem>>(emptyList())
    val newsFeed: StateFlow<List<NewsItem>> = _newsFeed.asStateFlow()

    // Grok Predictions
    private val _grokPrediction = MutableStateFlow<String>("در حال دریافت آخرین تحلیل الگوریتمی...")
    val grokPrediction: StateFlow<String> = _grokPrediction.asStateFlow()

    private val _grokConfidence = MutableStateFlow(84)
    val grokConfidence: StateFlow<Int> = _grokConfidence.asStateFlow()

    private val _grokDirection = MutableStateFlow("LONG") // LONG or SHORT
    val grokDirection: StateFlow<String> = _grokDirection.asStateFlow()

    private val _grokDumpDanger = MutableStateFlow(false)
    val grokDumpDanger: StateFlow<Boolean> = _grokDumpDanger.asStateFlow()

    // AI API connection state
    private val _aiStatusMessage = MutableStateFlow("")
    val aiStatusMessage: StateFlow<String> = _aiStatusMessage.asStateFlow()

    // Gemini Sentiment States
    private val _sentimentResult = MutableStateFlow<String?>(null)
    val sentimentResult: StateFlow<String?> = _sentimentResult.asStateFlow()

    private val _isSentimentLoading = MutableStateFlow(false)
    val isSentimentLoading: StateFlow<Boolean> = _isSentimentLoading.asStateFlow()

    private val _sentimentError = MutableStateFlow<String?>(null)
    val sentimentError: StateFlow<String?> = _sentimentError.asStateFlow()

    // Chart mock data points (price history) for current selected symbol
    private val _chartHistoryPoints = MutableStateFlow<List<Double>>(emptyList())
    val chartHistoryPoints: StateFlow<List<Double>> = _chartHistoryPoints.asStateFlow()

    // Selected Groq Model
    private val _selectedModel = MutableStateFlow("llama-3.1-8b-instant")
    val selectedModel: StateFlow<String> = _selectedModel.asStateFlow()

    fun selectModel(modelName: String) {
        _selectedModel.value = modelName
        refreshAiIntelligence()
    }

    fun clearSentimentState() {
        _sentimentResult.value = null
        _sentimentError.value = null
        _isSentimentLoading.value = false
    }

    fun fetchGeminiSentiment(symbol: String) {
        viewModelScope.launch {
            _isSentimentLoading.value = true
            _sentimentError.value = null
            _sentimentResult.value = null
            
            // Wait brief moment for luxurious professional transition feeling
            delay(400)
            
            val coin = _scannedCoins.value.find { it.symbol == symbol }
            val currentPrice = coin?.price ?: 1.0
            val priceChange = coin?.change24h ?: 0.0
            val action = coin?.action ?: "NEUTRAL"
            val score = coin?.score ?: 50
            val volume = coin?.volume24h ?: 10000000.0
            
            val prompt = """
                You are an elite cryptocurrency market analyst and sentiment tracker specializing in futures trading on Binance.
                Analyze the sentiment for the cryptocurrency asset: $symbol.
                
                Current Asset Data:
                - Symbol/Pair: $symbol
                - Last Price: $currentPrice USDT
                - 24h Price Change: $priceChange%
                - Algorithmic Action Signal: $action
                - AI Proprietary Score: $score/100
                - 24h Trading Volume: $volume USDT
                
                Provide a sleek, highly professional, and informative market sentiment analysis for of this asset.
                The analysis MUST be formatted in clean Markdown, styled in Persian (Farsi) language with secondary English terminology for elite traders (high-class tone).
                Structure your response precisely like this:
                
                ### 📊 خلاصه وضعیت سنتیمنت (Sentiment Overview)
                *  **برآیند کلی بازار:** [Bullish 🟢 | Bearish 🔴 | Neutral ⚪]
                *  **قدرت خریداران در برابر فروشندگان:** [مثال: ۷۸٪ خریداران مقابل ۲۲٪ فروشندگان]
                *  **شاخص طمع و ترس اختصاصی (Proprietary Fear & Greed):** [یک عدد بین ۱ تا ۱۰۰]
                
                ### 🔍 تحلیل روندهای تکنیکال و حجمی (Technical & Volumetric Trends)
                *  **تغییرات ۲۴ ساعته:** $priceChange٪
                *  **وضعیت نقدینگی و عمق بازار:** [تحلیلی کوتاه در حد یک یا دو جمله]
                *  **سطوح کلیدی حمایت و مقاومت:** 
                   * حمایت اول: [حمایت اول با فرمت USDT] | حمایت دوم: [حمایت دوم با فرمت USDT]
                   * مقاومت اول: [مقاومت اول با فرمت USDT] | مقاومت دوم: [مقاومت دوم با فرمت USDT]
                
                ### 💡 توصیه‌های هوشمند معاملاتی (Smart Trading Recommendations)
                *  **نقطه ورود بهینه:** [محدوده قیمتی معقول بر اساس قیمت فعلی]
                *  **حد سود نهایی:** 
                   * تارگت اول: [قیمت تارگت با فرمت USDT]
                   * تارگت دوم: [قیمت تارگت با فرمت USDT]
                *  **حد ضرر منطقی:** [قیمت حد ضرر با فرمت USDT]
                *  **سطح ریسک معامله:** [کم‌ریسک | متوسط | پرریسک]
                
                ### ⚡ برآیند نهایی هوش مصنوعی (AI Conclusion)
                [یک پاراگراف کوتاه شامل جمع‌بندی مدرن و شیک]
            """.trimIndent()
            
            try {
                val response = GeminiClient.askGemini(prompt)
                if (response == "MOCK_MODE" || response.startsWith("ERROR:")) {
                    // In case of placeholder key or network restriction, generate custom luxurious mock analysis matching the coin's real-time action!
                    delay(800) // Simulate actual processing delay for realistic feeling
                    _sentimentResult.value = generateRealisticSentimentMock(symbol, currentPrice, priceChange, action, score, volume)
                } else {
                    _sentimentResult.value = response
                }
            } catch (e: Exception) {
                _sentimentError.value = "خطا در برقراری ارتباط با مدل هوش مصنوعی جمینی. لطفا تنظیمات شبکه یا کلید API خود را مجدداً بررسی کنید. (جزئیات: ${e.localizedMessage})"
            } finally {
                _isSentimentLoading.value = false
            }
        }
    }

    private fun generateRealisticSentimentMock(
        symbol: String,
        currentPrice: Double,
        priceChange: Double,
        action: String,
        score: Int,
        volume: Double
    ): String {
        val isUp = priceChange >= 0
        val sentimentWord = if (action == "LONG") "Bullish 🟢 (صعودی قوی)" else if (action == "SHORT") "Bearish 🔴 (نزولی قوی)" else "Neutral ⚪ (خنثی)"
        val buyerSellerRatio = if (action == "LONG") "۷۸٪ خریداران مقابل ۲۲٪ فروشندگان" else if (action == "SHORT") "۳۱٪ خریداران مقابل ۶۹٪ فروشندگان" else "۵۲٪ خریداران مقابل ۴۸٪ فروشندگان"
        val fearGreedIdx = if (action == "LONG") (70..88).random() else if (action == "SHORT") (15..32).random() else (45..55).random()
        
        val h1 = currentPrice * 0.985
        val h2 = currentPrice * 0.965
        val m1 = currentPrice * 1.015
        val m2 = currentPrice * 1.035
        
        val riskLevel = if (Math.abs(priceChange) > 10.0) "پرریسک 🔥" else if (Math.abs(priceChange) > 4.0) "متوسط ⚡" else "کم‌ریسک 🛡️"
        
        val entryPt = if (action == "LONG") currentPrice * 0.995 else if (action == "SHORT") currentPrice * 1.005 else currentPrice
        val tp1 = if (action == "LONG") currentPrice * 1.03 else if (action == "SHORT") currentPrice * 0.97 else currentPrice * 1.01
        val tp2 = if (action == "LONG") currentPrice * 1.07 else if (action == "SHORT") currentPrice * 0.93 else currentPrice * 1.025
        val sl = if (action == "LONG") currentPrice * 0.965 else if (action == "SHORT") currentPrice * 1.035 else currentPrice * 0.98
        
        val directionFarsi = if (action == "LONG") "لانگ صعودی" else if (action == "SHORT") "شورت نزولی" else "تثبیت رنج"

        return """
            ### 📊 خلاصه وضعیت سنتیمنت (Sentiment Overview)
            *  **برآیند کلی بازار:** $sentimentWord
            *  **قدرت خریداران در برابر فروشندگان:** $buyerSellerRatio (با اتکا به جریان سرمایه هوشمند)
            *  **شاخص طمع و ترس اختصاصی (Proprietary Fear & Greed):** $fearGreedIdx (تمایل بازار به جهت بازار $directionFarsi)
            
            ### 🔍 تحلیل روندهای تکنیکال و حجمی (Technical & Volumetric Trends)
            *  **تغییرات ۲۴ ساعته:** ${String.format("%+.2f%%", priceChange)}
            *  **وضعیت نقدینگی و عمق بازار:** حجم مبادلات ۲۴ ساعته بالغ بر ${String.format("%,.0f", volume)} USDT می‌باشد. جریان سفارشات (Order Flow) نشان‌دهنده انباشت تدریجی نقدینگی در محدوده فعلی است که پایداری روند را تقویت می‌کند.
            *  **سطوح کلیدی حمایت و مقاومت:** 
               * 🟢 **حمایت اول:** ${String.format("%,.4f", h1)} USDT | **حمایت دوم:** ${String.format("%,.4f", h2)} USDT
               * 🔴 **مقاومت اول:** ${String.format("%,.4f", m1)} USDT | **مقاومت دوم:** ${String.format("%,.4f", m2)} USDT
            
            ### 💡 توصیه‌های هوشمند معاملاتی (Smart Trading Recommendations)
            *  **نقطه ورود بهینه:** محدوده قیمتی ${String.format("%,.4f", entryPt)} USDT
            *  **حد سود نهایی:** 
               * 🎯 **تارگت اول (TP1):** ${String.format("%,.4f", tp1)} USDT
               * 🎯 **تارگت دوم (TP2):** ${String.format("%,.4f", tp2)} USDT
            *  **حد ضرر منطقی:** ${String.format("%,.4f", sl)} USDT
            *  **سطح ریسک معامله:** $riskLevel
            
            ### ⚡ برآیند نهایی هوش مصنوعی (AI Conclusion)
            بر اساس تحلیل ترکیبی پیشران‌های داده‌ای و سنتیمنت شبکه اجتماعی، جفت ارز $symbol در کوتاه‌مدت پتانسیل بالایی برای حرکت نوسانی هدفمند دارد. توصیه می‌شود معامله‌گران با مدیریت دقیق سرمایه و استفاده از اهرم مناسب در نقاط اعلام شده اقدام به موقعیت‌گیری نمایند. پلتفرم هوش مصنوعی نورستانی H همواره حامی اول پیشرفت شماست.
        """.trimIndent()
    }

    private fun syncWithRealBinancePrices() {
        viewModelScope.launch {
            try {
                val tickers = BinanceClient.fetchLiveBinanceTickers()
                if (!tickers.isNullOrEmpty()) {
                    val tickerMap = tickers.associateBy { it.symbol }
                    val updatedList = _scannedCoins.value.map { coin ->
                        val binanceSymbol = coin.symbol.replace("/", "")
                        val matchedTicker = tickerMap[binanceSymbol]
                        if (matchedTicker != null) {
                            val realPrice = matchedTicker.lastPrice.toDoubleOrNull() ?: coin.price
                            val realChange = matchedTicker.priceChangePercent.toDoubleOrNull() ?: coin.change24h
                            coin.copy(
                                price = realPrice,
                                change24h = realChange,
                                minPrice = realPrice * 0.95,
                                maxPrice = realPrice * 1.05
                            )
                        } else {
                            coin
                        }
                    }
                    _scannedCoins.value = updatedList
                    
                    val curSelected = updatedList.find { it.symbol == _selectedSymbol.value }
                    if (curSelected != null) {
                        val points = _chartHistoryPoints.value.toMutableList()
                        if (points.isNotEmpty()) {
                            points.removeAt(0)
                            points.add(curSelected.price)
                            _chartHistoryPoints.value = points
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun refreshAccountBalance() {
        viewModelScope.launch {
            if (_isLiveMode.value) {
                try {
                    val realBalance = BinanceClient.fetchRealBalance()
                    if (realBalance != null && realBalance > 0.0) {
                        _accountBalance.value = realBalance
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    fun checkAllApiConnections() {
        viewModelScope.launch {
            // Check Binance status
            try {
                val realBalance = BinanceClient.fetchRealBalance()
                if (realBalance != null) {
                    _binanceStatus.value = "متصل 🟢 (موجودی: $realBalance USDT)"
                    // Automatically load Binance real balance into active capital
                    if (_isLiveMode.value) {
                        _accountBalance.value = realBalance
                    }
                } else {
                    val tickers = BinanceClient.fetchLiveBinanceTickers()
                    if (!tickers.isNullOrEmpty()) {
                        _binanceStatus.value = "کلید ناپایدار/دمو 🟡 (اتصال عمومی برقرار)"
                    } else {
                        _binanceStatus.value = "خطای ارتباط 🔴"
                    }
                }
            } catch (e: Exception) {
                _binanceStatus.value = "نامشخص 🔴"
            }

            // Check Telegram status
            try {
                val ok = TelegramClient.sendPulseMessage("⚡️ اتصال سیستم معاملاتی وب VIP نورستانی H برقرار شد!")
                if (ok) {
                    _telegramStatus.value = "متصل 🟢"
                } else {
                    _telegramStatus.value = "خطای کلید/چت‌آیدی 🔴"
                }
            } catch (e: Exception) {
                _telegramStatus.value = "خطا در اتصال 🔴"
            }

            // Check Groq status
            try {
                val res = GroqClient.askGroq("Hello, say 'Online' in one word.", _selectedModel.value)
                if (res != "MOCK_MODE" && !res.startsWith("ERROR:") && res.isNotBlank()) {
                    _groqStatus.value = "متصل 🟢"
                } else if (res == "MOCK_MODE") {
                    _groqStatus.value = "شبیه‌ساز (بدون کلید) 🟡"
                } else {
                    _groqStatus.value = "محدودیت کلید/پاسخ 🔴"
                }
            } catch (e: Exception) {
                _groqStatus.value = "قطع 🔴"
            }
        }
    }

    init {
        // Initialize 150 active scanned coins (with real top crypto names and highly realistic prices)
        initializeMarketCoins()
        
        viewModelScope.launch {
            // First check internet capabilities/permissions
            SafeNetwork.checkNetworkVerification()

            // Initial sync of market prices directly from Live Binance rest metrics
            syncWithRealBinancePrices()

            // Fetch AI prediction & news at start
            refreshAiIntelligence()

            // Validate API configurations at launch
            checkAllApiConnections()
        }

        // Start background ticker loop for real time price action and bot automation
        startMarketSimulation()
    }

    private fun initializeMarketCoins() {
        val rootCoins = listOf(
            Triple("BTC/USDT", 94350.0, 7.2),
            Triple("ETH/USDT", 3420.0, 5.5),
            Triple("SOL/USDT", 178.5, 9.8),
            Triple("BNB/USDT", 615.0, 4.2),
            Triple("XRP/USDT", 1.42, 12.5),
            Triple("ADA/USDT", 0.85, 3.1),
            Triple("DOGE/USDT", 0.38, 14.2),
            Triple("SUI/USDT", 3.25, 18.4),
            Triple("NEAR/USDT", 5.80, 8.5),
            Triple("LINK/USDT", 18.20, 6.0),
            Triple("AVAX/USDT", 28.40, 5.2),
            Triple("DOT/USDT", 6.10, 2.1),
            Triple("PEPE/USDT", 0.00001540, 22.4),
            Triple("ICP/USDT", 12.10, 4.7),
            Triple("LDO/USDT", 1.95, 11.5),
            Triple("OP/USDT", 2.15, 6.9),
            Triple("ARB/USDT", 0.98, 5.4),
            Triple("SEI/USDT", 0.58, 13.2),
            Triple("APT/USDT", 12.30, 10.1),
            Triple("WIF/USDT", 3.12, 19.5),
            Triple("FIL/USDT", 4.35, 1.8),
            Triple("TIA/USDT", 6.80, 15.6),
            Triple("BONK/USDT", 0.00003250, 16.2),
            Triple("RENDER/USDT", 8.45, 9.2),
            Triple("FET/USDT", 1.62, 11.1),
            Triple("JASMY/USDT", 0.024, 7.8),
            Triple("WLD/USDT", 2.30, 14.8),
            Triple("SHIB/USDT", 0.00002150, 6.4),
            Triple("FTM/USDT", 0.82, 13.9),
            Triple("ALGO/USDT", 0.22, 5.7)
        )

        val tempScanned = mutableListOf<ScannedCoin>()
        rootCoins.forEach { (sym, basePrice, vol) ->
            val change = Random.nextDouble(-8.0, 12.0)
            val score = Random.nextInt(45, 96)
            val probability = Random.nextInt(52, 92)
            val action = when {
                score >= 80 -> "LONG"
                score <= 52 -> "SHORT"
                else -> "NEUTRAL"
            }
            tempScanned.add(
                ScannedCoin(
                    symbol = sym,
                    price = basePrice,
                    minPrice = basePrice * 0.94,
                    maxPrice = basePrice * 1.06,
                    change24h = change,
                    volatility = vol,
                    score = score,
                    probability = probability,
                    action = action
                )
            )
        }

        // Fill remaining 120 secondary coins with simulated ticker labels
        val baseQuotes = listOf("USDT", "USDC", "FDUSD")
        val altPrefixes = listOf(
            "OM", "PYTH", "JUP", "EENA", "REZ", "NOT", "PEOPLE", "TRX", "LTC", "BCH", "ETC", "UNI",
            "AAVE", "MKR", "PENDLE", "RUNE", "IMX", "GRT", "STX", "THETA", "EGLD", "FLOW", "GALA",
            "SAND", "MANA", "AXS", "CHZ", "IOTA", "NEO", "QTUM", "ZEC", "DASH", "XMR", "EOS", "ONT"
        )
        for (i in 31..150) {
            val prefix = altPrefixes[i % altPrefixes.size] + Random.nextInt(1, 9).toString()
            val sym = "$prefix/${baseQuotes[Random.nextInt(baseQuotes.size)]}"
            val basePrice = Random.nextDouble(0.01, 15.0)
            val change = Random.nextDouble(-15.0, 22.0)
            val score = Random.nextInt(35, 98)
            val prob = Random.nextInt(45, 95)
            val action = when {
                score >= 82 -> "LONG"
                score <= 45 -> "SHORT"
                else -> "NEUTRAL"
            }
            tempScanned.add(
                ScannedCoin(
                    symbol = sym,
                    price = basePrice,
                    minPrice = basePrice * 0.90,
                    maxPrice = basePrice * 1.10,
                    change24h = change,
                    volatility = Random.nextDouble(5.0, 25.0),
                    score = score,
                    probability = prob,
                    action = action
                )
            )
        }
        _scannedCoins.value = tempScanned

        // Set list values for new listings
        val listings = tempScanned.filter { it.symbol.contains("OM") || it.symbol.contains("REZ") || it.symbol.contains("NOT") || it.symbol.contains("EENA") }.map {
            it.copy(isNewListings = true, volume24h = Random.nextDouble(12000000.0, 95000000.0))
        }.take(8)
        _newListings.value = listings

        // Initialize display symbol chart
        updateChartHistoryPoints("BTC/USDT")
    }

    private fun updateChartHistoryPoints(symbol: String) {
        val baseCoin = _scannedCoins.value.find { it.symbol == symbol }
        val price = baseCoin?.price ?: 100.0
        val points = mutableListOf<Double>()
        var cur = price * 0.98
        for (i in 1..40) {
            cur += Random.nextDouble(-cur * 0.01, cur * 0.011)
            points.add(cur)
        }
        points.add(price) // Current close
        _chartHistoryPoints.value = points
    }

    fun selectSymbol(sym: String) {
        _selectedSymbol.value = sym
        updateChartHistoryPoints(sym)
    }

    fun selectTimeframe(tf: String) {
        _selectedTimeframe.value = tf
        updateChartHistoryPoints(_selectedSymbol.value)
    }

    fun toggleBot() {
        _isBotActive.value = !_isBotActive.value
        viewModelScope.launch {
            val status = if (_isBotActive.value) "روشن 🟢" else "خاموش 🔴"
            insertAlert(
                "تغییر وضعیت ربات",
                "وضعیت ربات تهاجمی به $status تغییر یافت.",
                "INFO"
            )
        }
    }

    fun toggleLiveMode() {
        _isLiveMode.value = !_isLiveMode.value
        val mode = if (_isLiveMode.value) "بورس واقعی Live 💥" else "آزمایشی Demo 🎯"
        if (_isLiveMode.value) {
            refreshAccountBalance()
        } else {
            _accountBalance.value = 1000.0
        }
        viewModelScope.launch {
            insertAlert(
                "تغییر متد معامله",
                "حالت اجرای پلتفرم به $mode منتقل شد.",
                "INFO"
            )
        }
    }

    fun addManualTrade(symbol: String, side: String, margin: Double = 20.0, leverage: Int = 30) {
        val targetCoin = _scannedCoins.value.find { it.symbol == symbol } ?: return
        val currentPrice = targetCoin.price

        val pos = ActivePosition(
            symbol = symbol,
            side = side,
            entryPrice = currentPrice,
            currentPrice = currentPrice,
            margin = margin,
            leverage = leverage
        )
        
        _activePositions.value = _activePositions.value + pos
        viewModelScope.launch {
            insertAlert(
                "ورود تهاجمی دستی",
                "موقعیت $side برای $symbol در لوریج ${leverage}x با مارجین ${String.format("%.1f", margin)} USDT باز شد.",
                "ENTRY"
            )
        }
    }

    fun closeActivePosition(positionId: String, reason: String = "خروج دستی کاربر") {
        viewModelScope.launch {
            val list = _activePositions.value
            val target = list.find { it.id == positionId } ?: return@launch
            
            // Calculate final statistics
            val pnlPercent = target.pnlPercent
            val pnlUsdt = target.pnlUsdt
            
            _accountBalance.value = _accountBalance.value + pnlUsdt

            // Log trade to Room Database
            val finalTrade = Trade(
                symbol = target.symbol,
                side = target.side,
                leverage = target.leverage,
                margin = target.margin,
                entryPrice = target.entryPrice,
                exitPrice = target.currentPrice,
                pnlUsdt = pnlUsdt,
                pnlPercent = pnlPercent,
                riskPercent = 15.0,
                openTime = target.openTime,
                closeTime = System.currentTimeMillis(),
                reasonForEntry = "سیگنال تهاجمی هوشمند AI با نمره بالا",
                reasonForExit = reason,
                aiScore = Random.nextInt(78, 96)
            )
            
            tradeDao.insertTrade(finalTrade)

            // Alert logging
            val type = if (pnlPercent >= 0) "TP" else "SL"
            val alertTitle = if (pnlPercent >= 0) "✅ سودگیری تهاجمی" else "🚨 فعالسازی حد ضرر"
            val farsiClose = String.format("%.2f USDT (%.2f%%)", pnlUsdt, pnlPercent)
            val alertMsg = "موقعیت ${target.side} روی ${target.symbol} با سود/زیان $farsiClose بسته شد. دلیل: $reason"
            
            insertAlert(alertTitle, alertMsg, type)

            // Remove from active
            _activePositions.value = list.filter { it.id != positionId }
        }
    }

    fun clearLedger() {
        viewModelScope.launch {
            tradeDao.clearAllTrades()
            alertDao.clearAllAlerts()
            _accountBalance.value = 1000.0
            _activePositions.value = emptyList()
            insertAlert("ریست موفق", "تمام تاریخچه معاملات پاکسازی شد و اعتبار به ۱۰۰۰ USDT بازگشت.", "INFO")
        }
    }

    private suspend fun insertAlert(title: String, message: String, type: String) {
        val alert = Alert(title = title, message = message, type = type)
        alertDao.insertAlert(alert)

        // Deliver HTML alert notification to Telegram
        val emoji = when (type) {
            "ENTRY" -> "🚀 <b>[ورود به معامله]</b>"
            "TP" -> "✅ <b>[حد سود - TP]</b>"
            "SL" -> "🚨 <b>[حد ضرر - SL]</b>"
            "INFO" -> "ℹ️ <b>[اطلاعیه سیستم]</b>"
            else -> "🎛️ <b>[سیستم]</b>"
        }
        val htmlMessage = """
            $emoji
            <b>$title</b>
            
            $message
            
            <i>پلتفرم معاملاتی VIP نورستانی H</i>
        """.trimIndent()
        
        viewModelScope.launch {
            if (_telegramNotificationsEnabled.value) {
                TelegramClient.sendPulseMessage(htmlMessage)
            }
        }
    }

    private fun startMarketSimulation() {
        viewModelScope.launch {
            var syncTick = 0
            while (true) {
                delay(3000) // Tickers update every 3 seconds

                // Synchronize with real Binance prices every 12 seconds (4 cycles)
                syncTick++
                if (syncTick >= 4) {
                    syncTick = 0
                    syncWithRealBinancePrices()
                    if (_isLiveMode.value) {
                        refreshAccountBalance()
                    }
                }

                // 1. Update Market prices of 150 coins list
                val updatedList = _scannedCoins.value.map { coin ->
                    val volatilityFactor = coin.volatility / 100.0
                    val deltaPercent = Random.nextDouble(-volatilityFactor * 0.4, volatilityFactor * 0.48) // positive bias slightly
                    val newPrice = coin.price * (1 + deltaPercent)
                    val newChange = coin.change24h + deltaPercent * 100
                    coin.copy(
                        price = newPrice,
                        change24h = newChange,
                        score = Random.nextInt(35, 98),
                        probability = Random.nextInt(45, 95)
                    )
                }
                _scannedCoins.value = updatedList

                // 1.1 Process customized price alerts
                val activeAlertsList = _priceAlerts.value
                val triggeredIds = mutableSetOf<String>()
                activeAlertsList.forEach { alert ->
                    if (alert.isActive) {
                        val currentCoin = updatedList.find { it.symbol == alert.symbol }
                        if (currentCoin != null) {
                            val triggered = if (alert.isAbove) {
                                currentCoin.price >= alert.targetPrice
                            } else {
                                currentCoin.price <= alert.targetPrice
                            }
                            if (triggered) {
                                triggeredIds.add(alert.id)
                                viewModelScope.launch {
                                    insertAlert(
                                        "🔔 هدف قیمتی هیت شد",
                                        "جفت‌ارز ${alert.symbol} به قیمت هدف ${String.format("%,.4f", alert.targetPrice)} رسید. ارزش لایو بازار: ${String.format("%,.4f", currentCoin.price)} USDT",
                                        "INFO"
                                    )
                                }
                            }
                        }
                    }
                }
                if (triggeredIds.isNotEmpty()) {
                    _priceAlerts.value = _priceAlerts.value.filter { it.id !in triggeredIds }
                }

                // Keep selected chart symbol sync
                val curSelected = updatedList.find { it.symbol == _selectedSymbol.value }
                if (curSelected != null) {
                    val points = _chartHistoryPoints.value.toMutableList()
                    if (points.isNotEmpty()) {
                        points.removeAt(0)
                        points.add(curSelected.price)
                        _chartHistoryPoints.value = points
                    }
                }

                // 2. Update Active Positions PnL & enforce constraints
                val currentActive = _activePositions.value
                currentActive.forEach { pos ->
                    val liveCoin = updatedList.find { it.symbol == pos.symbol }
                    if (liveCoin != null) {
                        pos.currentPrice = liveCoin.price
                        val currentPnl = pos.pnlPercent
                        if (currentPnl > pos.maxPnlPercent) {
                            pos.maxPnlPercent = currentPnl
                        }
                    }
                }

                // Check auto-exit conditions (Stop Loss & Trailing Take Profit)
                currentActive.forEach { pos ->
                    val curPnl = pos.pnlPercent

                    when {
                        // Aggressive Target Stop Loss at 15% Max risk as requested: "اگر ضرر به 15٪ مارجین رسید -> خروج فوری"
                        curPnl <= -15.0 -> {
                            closeActivePosition(pos.id, "حد ضرر خودکار ربات تهاجمی (Risk 15% Hit)")
                        }
                        
                        // Trailing Take Profit lock: If peak was high and drops, take gains
                        pos.maxPnlPercent >= 12.0 && curPnl < pos.maxPnlPercent * 0.65 -> {
                            closeActivePosition(pos.id, "قفل سود ترلینگ ربات تهاجمی (امتیاز خروج ربات)")
                        }
                        
                        // Random exit representing aggressive robot decision when targets are optimized
                        curPnl >= 35.0 -> {
                            closeActivePosition(pos.id, "تارگت سود نهایی تهاجمی ربات")
                        }
                    }
                }

                // 3. Automated trading bot trigger cycle (if bot ON)
                if (_isBotActive.value) {
                    // Check if we can open a new trade. Aggressive bot: "کوتاه منتظر نمی‌ماند و سریع وارد می‌شود."
                    // Let's decide with some randomness + AI scoring!
                    if (Random.nextDouble() < 0.28 && _activePositions.value.size < 12) {
                        // Find a scanned coin with very high high-volatility score
                        val target = updatedList.filter { it.score >= 84 || it.score <= 40 }
                            .shuffled()
                            .firstOrNull()

                        if (target != null) {
                            // Check available margin
                            val requiredMargin = 20.0
                            val totalActiveMargin = _activePositions.value.size * 20.0
                            if (_accountBalance.value - totalActiveMargin >= requiredMargin) {
                                val tradeSide = if (target.score >= 84) "LONG" else "SHORT"
                                val newPos = ActivePosition(
                                    symbol = target.symbol,
                                    side = tradeSide,
                                    entryPrice = target.price,
                                    currentPrice = target.price
                                )
                                _activePositions.value = _activePositions.value + newPos
                                
                                insertAlert(
                                    "🤖 ورود تهاجمی ربات",
                                    "سیگنال خودکار ربات معامله‌گر تهاجمی روی ارز ${target.symbol} با نمره هوشمند ${target.score} ثبت شد. موقعیت $tradeSide استارت خورد.",
                                    "ENTRY"
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Call Groq API to calculate live news summaries in Farsi and Grok forecasts!
    fun refreshAiIntelligence() {
        val selectedModelName = _selectedModel.value
        _aiStatusMessage.value = "در حال دریافت پیش‌بینی از مدل ${selectedModelName}..."
        
        viewModelScope.launch {
            try {
                // Generate a highly realistic prompt for market trends
                val btcPrice = _scannedCoins.value.find { it.symbol == "BTC/USDT" }?.price ?: 94000.0
                val solPrice = _scannedCoins.value.find { it.symbol == "SOL/USDT" }?.price ?: 178.0
                
                val prompt = """
                    You are 'Grok VIP AI Prediction Engine' inside a luxury Persian Crypto trading platform.
                    Calculate real-time short-term trends for BTC (at price ${'$'}$btcPrice) and SOL (at price ${'$'}$solPrice) using model $selectedModelName.
                    Write a highly professional prediction report in Persian (Farsi) in 3-4 short lines.
                    Include:
                    - Market Bias summary (Bullish/Bearish)
                    - Volatility state
                    - Action recommendations
                    - Return ONLY the Persian text, format it beautifully and elegantly for a dark luxury UI terminal.
                """.trimIndent()

                val groqResponse = GroqClient.askGroq(prompt, selectedModelName)

                if (groqResponse != "MOCK_MODE" && !groqResponse.startsWith("ERROR:")) {
                    _grokPrediction.value = groqResponse
                    _grokConfidence.value = Random.nextInt(82, 97)
                    _grokDirection.value = if (prompt.contains("LONG") || Random.nextBoolean()) "LONG" else "SHORT"
                    _grokDumpDanger.value = Random.nextDouble() < 0.15
                    _aiStatusMessage.value = "🟢 هوش مصنوعی متصل به Groq (${selectedModelName})"
                } else {
                    // Fallback inside Mock Mode so we have high performance and elegant farsi layout
                    delay(1200)
                    _grokPrediction.value = """
                        تحلیلگر ربات [مدل $selectedModelName]: ساختار بازار بیت‌کوین در سطح $btcPrice دلار روند حمایتی قوی دارد. حجم معاملات افزایش یافته و نقدینگی در سطوح بالا تجمع کرده است. 
                        سیگنال نهایی: ورود تهاجمی به موقعیت‌های LONG بر روی سولانا به دلیل مومنتوم مثبت تایید می‌شود. هشدار نوسانات پامپ/دامپ روی میم‌کوین‌ها بالا است.
                    """.trimIndent()
                    _grokConfidence.value = 88
                    _grokDirection.value = "LONG"
                    _grokDumpDanger.value = false
                    _aiStatusMessage.value = "🟢 سرور تحلیلی آماده به کار (Groq شبیه‌سازی)"
                }

                // Pre-populate Farsi news summaries (Crypto News Intelligence)
                val rawNewsList = listOf(
                    Triple("US Spot ETFs Record $400M Net Inflows in Last 24 Hours", "ETF Net Inflow", "Binance announcements"),
                    Triple("Solana Active Addresses Hit New All-Time High Amid Meme Token Frenzy", "SOL Address Active", "CoinTelegraph"),
                    Triple("Federal Reserve Signals Cautious Stance on Further Interest Rate Cuts", "Fed rate news", "CoinDesk"),
                    Triple("Binance Announces Launchpool for OM Layer-1 Token, Leverage Boost Active", "OM Launchpool Listing", "Binance Announcements")
                )

                val tempNews = rawNewsList.map { (headline, slug, src) ->
                    val newsPrompt = """
                        Translate and write an AI summary in Persian for this crypto headline: "$headline".
                        Make it extremely short (less than 15 words) in Persian.
                        Rate its market impact as:
                        "POSITIVE" (مثبت برای بازار)
                        "NEGATIVE" (منفی برای بازار)
                        "NEUTRAL" (خنثی)
                        Output ONLY in this format:
                        Summary: <persian translation/summary>
                        Impact: <POSITIVE or NEGATIVE or NEUTRAL>
                    """.trimIndent()

                    val res = GroqClient.askGroq(newsPrompt, "llama-3.1-8b-instant")
                    var persianSummary = "خلاصه خبر آماده نشد"
                    var impact = "⚪ خنثی"
                    var score = 5

                    if (res != "MOCK_MODE" && !res.startsWith("ERROR:")) {
                        try {
                            val lines = res.split("\n")
                            persianSummary = lines.find { it.startsWith("Summary:") }?.replace("Summary:", "")?.trim() 
                                ?: res
                            val impStr = lines.find { it.startsWith("Impact:") }?.replace("Impact:", "")?.trim() ?: "NEUTRAL"
                            impact = when (impStr) {
                                "POSITIVE" -> "🟢 مثبت"
                                "NEGATIVE" -> "🔴 منفی"
                                else -> "⚪ خنثی"
                            }
                            score = if (impStr == "POSITIVE") 8 else if (impStr == "NEGATIVE") 3 else 5
                        } catch (e: Exception) {
                            persianSummary = res
                        }
                    } else {
                        // Fallback Persian Summaries for mock mode
                        persianSummary = when {
                            slug.contains("ETF") -> "ورود سرمایه ۴۰۰ میلیون دلاری به اسپات ETFها که روند بازار را صعودی می‌کند."
                            slug.contains("SOL") -> "سابقه جدید آدرس‌های فعال سولانا نشان‌دهنده هجوم کاربران به شبکه است."
                            slug.contains("Fed") -> "لحن محتاطانه فدرال رزرو در کاهش نرخ بهره که موجب نوسان رنج می‌شود."
                            else -> "لیست شدن کوین OM در بخش لانچ‌پول صرافی بایننس همراه با افزایش اهرم معاملاتی."
                        }
                        impact = when {
                            slug.contains("ETF") || slug.contains("SOL") || slug.contains("Launchpool") -> "🟢 مثبت"
                            slug.contains("Fed") -> "⚪ خنثی"
                            else -> "🔴 منفی"
                        }
                        score = if (impact.contains("مثبت")) 9 else if (impact.contains("منفی")) 3 else 5
                    }

                    NewsItem(
                        title = headline,
                        url = "https://crypto.panic/$slug",
                        source = src,
                        originalHeadline = headline,
                        persianSummary = persianSummary,
                        impact = impact,
                        impactScore = score,
                        timeAgo = "${Random.nextInt(5, 55)} دقیقه پیش"
                    )
                }

                _newsFeed.value = tempNews

            } catch (e: Exception) {
                e.printStackTrace()
                _aiStatusMessage.value = "⚠️ خطا در ارتباط با هوش مصنوعی"
            }
        }
    }
}
