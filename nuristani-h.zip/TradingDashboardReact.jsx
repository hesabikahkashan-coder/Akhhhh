import React, { useState, useEffect } from 'react';

// Core luxury design color palette (Tailwind compliant names used within custom styles)
// Obsidian Deep Dark Base: #050505
// Luxury Gold Amber: #F59E0B / #FBBF24
// Active Neon Cyan: #00E1D4
// Bullish Green: #10B981
// Bearish Red: #EF4444

export default function TradingDashboardReact() {
  const [isLiveMode, setIsLiveMode] = useState(false);
  const [isBotActive, setIsBotActive] = useState(true);
  const [balance, setBalance] = useState(128450.75);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  // Real-time crypto currency price states
  const [tickers, setTickers] = useState([
    { symbol: 'BTC/USDT', name: 'Bitcoin', price: 96420.50, change24h: 3.84, volume: '1.24B', isUp: true },
    { symbol: 'ETH/USDT', name: 'Ethereum', price: 3412.75, change24h: -1.25, volume: '840M', isUp: false },
    { symbol: 'SOL/USDT', name: 'Solana', price: 184.90, change24h: 8.42, volume: '620M', isUp: true },
    { symbol: 'BNB/USDT', name: 'Binance Coin', price: 612.35, change24h: 0.15, volume: '210M', isUp: true },
    { symbol: 'XRP/USDT', name: 'Ripple', price: 1.1450, change24h: -2.48, volume: '190M', isUp: false },
    { symbol: 'ADA/USDT', name: 'Cardano', price: 0.5840, change24h: 1.12, volume: '95M', isUp: true },
    { symbol: 'AVAX/USDT', name: 'Avalanche', price: 28.65, change24h: -0.85, volume: '88M', isUp: false },
  ]);

  // Active trades state
  const [activePositions, setActivePositions] = useState([
    { id: 1, symbol: 'SOL/USDT', side: 'LONG', leverage: 30, entryPrice: 182.10, currentPrice: 184.90, pnlPercent: 4.61, pnlUsdt: 215.40 },
    { id: 2, symbol: 'BTC/USDT', side: 'LONG', leverage: 20, entryPrice: 95800.00, currentPrice: 96420.50, pnlPercent: 1.29, pnlUsdt: 124.80 },
  ]);

  // Network connection statuses
  const [connections] = useState({
    binance: { name: 'Binance API Feed', status: 'ACTIVE 🟢', delay: '24ms' },
    groq: { name: 'Groq AI Engine', status: 'ACTIVE 🟢', delay: '142ms' },
    telegram: { name: 'Telegram Bot Hub', status: 'ACTIVE 🟢', delay: '88ms' },
    gemini: { name: 'Google Gemini Sentiment', status: 'CONNECTED ✨', delay: '120ms' }
  });

  // Simulation: Update prices randomly in real-time
  useEffect(() => {
    const interval = setInterval(() => {
      setTickers(prev => prev.map(t => {
        const volatility = t.symbol.startsWith('SOL') ? 0.003 : 0.001;
        const changePercent = (Math.random() - 0.49) * volatility;
        const newPrice = t.price * (1 + changePercent);
        const diffPercent = changePercent * 100;
        const newChange = t.change24h + diffPercent;
        
        return {
          ...t,
          price: Number(newPrice.toFixed(t.price > 100 ? 2 : 4)),
          change24h: Number(newChange.toFixed(2)),
          isUp: changePercent >= 0
        };
      }));

      // Update balance slightly if bot is active
      if (isBotActive) {
        setBalance(prev => {
          const delta = (Math.random() - 0.47) * 4.5;
          return Number((prev + delta).toFixed(2));
        });
      }

      // Update positions live as tickers tick
      setActivePositions(prev => prev.map(pos => {
        if (pos.symbol === 'SOL/USDT') {
          const matched = tickers.find(t => t.symbol === 'SOL/USDT');
          if (matched) {
            const pnlP = ((matched.price - pos.entryPrice) / pos.entryPrice) * pos.leverage * 100;
            return {
              ...pos,
              currentPrice: matched.price,
              pnlPercent: Number(pnlP.toFixed(2)),
              pnlUsdt: Number((pnlP * 4.5).toFixed(2))
            };
          }
        }
        if (pos.symbol === 'BTC/USDT') {
          const matched = tickers.find(t => t.symbol === 'BTC/USDT');
          if (matched) {
            const pnlP = ((matched.price - pos.entryPrice) / pos.entryPrice) * pos.leverage * 100;
            return {
              ...pos,
              currentPrice: matched.price,
              pnlPercent: Number(pnlP.toFixed(2)),
              pnlUsdt: Number((pnlP * 8.5).toFixed(2))
            };
          }
        }
        return pos;
      }));

      setLastUpdated(new Date());
    }, 1500);

    return () => clearInterval(interval);
  }, [isBotActive, tickers]);

  // Handle position exit
  const handleExitPosition = (id) => {
    setActivePositions(prev => prev.filter(pos => pos.id !== id));
  };

  return (
    <div style={{ backgroundColor: '#050505', color: '#F8FAFC', minHeight: '100vh', direction: 'rtl', fontFamily: 'system-ui, -apple-system, sans-serif' }} className="p-4 md:p-8">
      
      {/* 1. Header Area */}
      <header className="flex flex-col md:flex-row justify-between items-center gap-4 mb-8 border-b border-white/5 pb-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-gradient-to-r from-amber-500 to-amber-300 p-[1.5px]">
            <div className="w-full h-full bg-black rounded-full flex items-center justify-center font-bold text-amber-500 text-xl">
              N
            </div>
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-bold tracking-wide text-transparent bg-clip-text bg-gradient-to-l from-white to-slate-300">
              پلتفرم هوش مصنوعی نورستانی H
            </h1>
            <p className="text-xs text-emerald-400 font-semibold flex items-center gap-1.5 mt-0.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block animate-pulse"></span>
              سیستم معاملاتی آنلاین و هماهنگ با Binance Rest Feed
            </p>
          </div>
        </div>
        
        {/* App Meta Indicators */}
        <div className="flex items-center gap-3">
          <div className="text-left text-xs text-slate-400 hidden md:block">
            <span className="block font-mono text-slate-500">Live Timestamp</span>
            <span className="font-mono text-amber-400">{lastUpdated.toLocaleTimeString()}</span>
          </div>
          <button 
            onClick={() => setIsBotActive(!isBotActive)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all duration-300 pointer-events-auto border flex items-center gap-2 ${
              isBotActive 
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20' 
                : 'bg-rose-500/10 border-rose-500/30 text-rose-400 hover:bg-rose-500/20'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${isBotActive ? 'bg-emerald-400 animate-ping' : 'bg-rose-400'}`}></span>
            {isBotActive ? 'ربات فعال است' : 'ربات غیرفعال'}
          </button>
        </div>
      </header>

      {/* 2. REAL-TIME RUNNING TICKER ROW (HORIZONTALLY SCROLLABLE) */}
      <section className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xs font-bold uppercase tracking-wider text-amber-400/80 flex items-center gap-2">
            <span>✨</span> نرخ‌های لحظه‌ای بایننس (Binance Real-Time Tickers)
          </h2>
          <span className="text-[10px] text-slate-500">بروزرسانی زنده هر ۱.۵ ثانیه</span>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3 overflow-x-auto no-scrollbar py-2">
          {tickers.map(t => (
            <div 
              key={t.symbol} 
              className="bg-zinc-950/40 p-4.5 rounded-2xl border border-white/[0.04] hover:border-amber-500/30 transition-all duration-300 flex flex-col justify-between"
              style={{ minWidth: '135px' }}
            >
              <div>
                <span className="text-[10px] text-slate-500 font-mono block">{t.name}</span>
                <span className="text-sm font-bold text-white font-mono">{t.symbol.split('/')[0]}</span>
              </div>
              
              <div className="mt-3">
                <div className="text-base font-bold font-mono tracking-tight text-slate-100 transition-all duration-500">
                  {t.price.toLocaleString(undefined, { minimumFractionDigits: t.price > 100 ? 2 : 4 })}
                </div>
                <div className={`text-[11px] font-mono font-bold mt-1 inline-flex items-center gap-0.5 ${t.change24h >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {t.change24h >= 0 ? '▲' : '▼'} {Math.abs(t.change24h).toFixed(2)}%
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Main Body Split Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left 2 Columns: Financial Info & Active Positions */}
        <div className="lg:col-span-2 flex flex-col gap-8">
          
          {/* A. Balance & PNL Card */}
          <section className="bg-gradient-to-b from-white/[0.08] to-white/[0.02] rounded-3xl border border-white/[0.08] p-6 shadow-2xl relative overflow-hidden">
            {/* Ambient Background Glow */}
            <div className="absolute top-0 right-0 w-48 h-48 bg-amber-500/5 rounded-full blur-3xl pointer-events-none"></div>
            
            <div className="flex justify-between items-center mb-6">
              <div>
                <p className="text-xs text-slate-400 font-medium">موجودی ارزشمند کل سبد فریز شده (Asset Margin Balance)</p>
                <h3 className="text-3xl md:text-4xl font-extrabold tracking-tight text-white font-mono mt-1.5">
                  {balance.toLocaleString(undefined, { minimumFractionDigits: 2 })} <span className="text-amber-400 text-lg md:text-xl">USDT</span>
                </h3>
              </div>
              
              {/* Dynamic Live Switch */}
              <div 
                onClick={() => setIsLiveMode(!isLiveMode)}
                className="cursor-pointer bg-black/40 border border-white/[0.06] rounded-2xl px-4 py-2 flex items-center gap-2.5 hover:border-amber-500/20 transition-all duration-300"
              >
                <div className={`w-2.5 h-2.5 rounded-full ${isLiveMode ? 'bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.6)]' : 'bg-[#00E1D4] shadow-[0_0_8px_rgba(0,225,212,0.6)]'}`}></div>
                <span className="text-xs font-bold text-slate-300">
                  {isLiveMode ? 'حالت واقعی LIVE' : 'شبیه‌ساز DEMO'}
                </span>
              </div>
            </div>

            <div className="h-[1px] bg-white/[0.07] mb-6"></div>

            {/* Performance Stats Subgrid */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-zinc-950/30 p-4 rounded-xl border border-white/[0.03]">
                <p className="text-[10px] text-slate-500">سود ناخالص امروز (Estimated Today Profit)</p>
                <p className="text-base font-extrabold font-mono text-emerald-400 mt-1">
                  +1,424.12 USDT
                </p>
              </div>
              <div className="bg-zinc-950/30 p-4 rounded-xl border border-white/[0.03]">
                <p className="text-[10px] text-slate-500">بازدهی کل دوره ربات (Total System PnL)</p>
                <p className="text-base font-extrabold font-mono text-emerald-400 mt-1">
                  +12,894.40 USDT
                </p>
              </div>
            </div>
          </section>

          {/* B. Active Positions Section */}
          <section>
            <div className="flex justify-between items-center mb-5">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <span className="w-1.5 h-4 bg-amber-500 rounded-sm"></span>
                موقعیت‌های معاملاتی فعال هجومی (Active Scalp Positions)
              </h3>
              <span className="text-xs font-mono font-bold text-slate-400">
                {activePositions.length} موقعیت باز
              </span>
            </div>

            {activePositions.length === 0 ? (
              <div className="bg-zinc-950/20 border border-dashed border-white/10 rounded-2xl p-12 text-center text-slate-500">
                <p className="text-sm font-bold">موقعیت فعالی یافت نشد</p>
                <p className="text-xs text-slate-600 mt-1">منتظر دریافت سیگنال‌های پیشرفته از پایانه بایننس...</p>
              </div>
            ) : (
              <div className="flex flex-col gap-4">
                {activePositions.map(pos => {
                  const isBullish = pos.pnlPercent >= 0;
                  return (
                    <div 
                      key={pos.id} 
                      className={`bg-zinc-950/40 rounded-2xl border p-5 transition-all duration-300 ${
                        isBullish ? 'border-emerald-500/20 hover:border-emerald-500/40' : 'border-rose-500/20 hover:border-rose-500/40'
                      }`}
                    >
                      <div className="flex justify-between items-center mb-4">
                        <div className="flex items-center gap-3">
                          <span className={`text-[10px] font-extrabold px-2.5 py-1 rounded-md ${
                            pos.side === 'LONG' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'
                          }`}>
                            {pos.side} {pos.leverage}x
                          </span>
                          <span className="text-base font-bold font-mono text-white">{pos.symbol}</span>
                        </div>
                        <button 
                          onClick={() => handleExitPosition(pos.id)}
                          className="bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-bold px-3 py-1.5 rounded-lg border border-rose-500/20 transition-all duration-200"
                        >
                          بستن تسویه
                        </button>
                      </div>

                      <div className="grid grid-cols-3 gap-2 text-right">
                        <div>
                          <span className="text-[10px] text-slate-500 block">قیمت ورود</span>
                          <span className="text-xs font-bold font-mono text-slate-300">{pos.entryPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-500 block">قیمت زنده</span>
                          <span className="text-xs font-bold font-mono text-slate-300">{pos.currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                        </div>
                        <div className="text-left">
                          <span className="text-[10px] text-slate-500 block text-left">سود و زیان غیرواقعی</span>
                          <span className={`text-sm font-extrabold font-mono inline-block ${isBullish ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {isBullish ? '+' : ''}{pos.pnlPercent}% ({pos.pnlUsdt > 0 ? '+' : ''}{pos.pnlUsdt} USDT)
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>

        </div>

        {/* Right 1 Column: Terminal Monitoring Panel */}
        <div className="flex flex-col gap-6">
          
          {/* Terminal Connection Monitors */}
          <section className="bg-zinc-950/60 border border-white/[0.05] rounded-3xl p-6.5">
            <h3 className="text-xs font-extrabold text-amber-500 tracking-wider mb-5 flex items-center gap-2">
              <span className="inline-block w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse"></span>
              پایانه‌های ارتباطی فعال (VIP Connectors)
            </h3>
            
            <div className="flex flex-col gap-4">
              {Object.entries(connections).map(([key, connection]) => (
                <div key={key} className="bg-black/30 p-3.5 rounded-2xl border border-white/[0.03] flex items-center justify-between">
                  <div>
                    <p className="text-xs font-bold text-slate-200">{connection.name}</p>
                    <p className="text-[10px] text-slate-500 font-mono mt-0.5">Latency: {connection.delay}</p>
                  </div>
                  <span className="text-[11px] font-extrabold text-amber-400 font-mono bg-amber-500/5 px-2.5 py-1 rounded-md border border-amber-500/10">
                    {connection.status}
                  </span>
                </div>
              ))}
            </div>

            <div className="mt-6 p-4 rounded-2xl bg-gradient-to-l from-amber-500/5 to-transparent border border-amber-500/10 text-right">
              <h4 className="text-xs font-bold text-amber-400">تضمین پایداری ارتباط</h4>
              <p className="text-[10px] text-slate-400 leading-relaxed mt-1">
                سنجش پایداری مسیر انتقال از طریق سیستم‌های پروکسی پرسرعت امنیتی جهت جلوگیری از بسته‌شدن حساب‌ها بررسی می‌گردد.
              </p>
            </div>
          </section>

          {/* Quick AI Insight Box */}
          <section className="bg-gradient-to-b from-emerald-500/[0.07] to-transparent border border-emerald-500/15 rounded-3xl p-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-8 h-8 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-400 font-bold">
                💡
              </div>
              <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider">سنتیمنت هوش مصنوعی جمینی</h4>
            </div>
            
            <p className="text-xs text-slate-300 leading-relaxed text-right">
              روند بازار در وضعیت <strong className="text-emerald-400">مثبت 🟢 (Bullish)</strong> ارزیابی می‌شود. الگوهای نفوذ به مقاومت‌های معتبر بیت‌کوین نشان‌دهنده پایداری سطوح بالاتر از ۹۶ هزار دلار است. ربات نورستانی H بر اساس موقعیت‌های نقدینه به شکار سود ادامه می‌دهد.
            </p>
          </section>

        </div>

      </div>

      {/* Footer Area */}
      <footer className="mt-12 pt-6 border-t border-white/5 flex flex-col md:flex-row justify-between items-center text-slate-600 text-xs">
        <p>© 2026 پلتفرم معاملاتی هوشمند نورستانی H - کلیه حقوق محفوظ است.</p>
        <p className="mt-2 md:mt-0 font-mono">Build 2.6.4 (Gemini Ultra Optimized)</p>
      </footer>

    </div>
  );
}
